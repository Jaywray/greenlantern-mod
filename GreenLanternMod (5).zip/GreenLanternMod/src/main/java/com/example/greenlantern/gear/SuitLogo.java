package com.example.greenlantern.gear;

public record SuitLogo(String model, float scale, float top, float side) {
   public SuitLogo(String model, float scale, float top) {
      this(model, scale, top, 0.0F);
   }
}
