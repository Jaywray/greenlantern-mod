package com.example.greenlantern.ability;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ClientFlightState {
   private static final Set<Integer> FLYING = ConcurrentHashMap.newKeySet();
   private static final Map<Integer, float[]> FACINGS = new ConcurrentHashMap();

   public static void set(int entityId, boolean flying) {
      if (flying) {
         FLYING.add(entityId);
      } else {
         FLYING.remove(entityId);
         FACINGS.remove(entityId);
      }

   }

   public static boolean isFlying(int entityId) {
      return FLYING.contains(entityId);
   }

   public static void setFacing(int entityId, float[] facing) {
      if (facing == null) {
         FACINGS.remove(entityId);
      } else {
         FACINGS.put(entityId, facing);
      }

   }

   public static float[] facing(int entityId) {
      return (float[])FACINGS.get(entityId);
   }

   public static void clear() {
      FLYING.clear();
      FACINGS.clear();
   }
}
