package com.example.greenlantern.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidType;

public class CarrierBubbleEntity extends Projectile {

   public CarrierBubbleEntity(EntityType<? extends Projectile> type, Level level) {
      super(type, level);
   }

   @Override
   protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
      // Initializes synchronous transport tracking data keys smoothly
   }

   @Override
   protected void onHitEntity(EntityHitResult result) {
      super.onHitEntity(result);
      if (!this.level().isClientSide() && result.getEntity() instanceof LivingEntity target) {
         // Locks the passenger into the carrier bubble transport node natively
         target.startRiding(this);
      }
   }

   @Override
   protected void onHitBlock(BlockHitResult result) {
      super.onHitBlock(result);
      if (!this.level().isClientSide()) {
         this.discard();
      }
   }

   @Override
   public void tick() {
      super.tick();
      this.checkInsideBlocks();
      net.minecraft.world.phys.Vec3 movement = this.getDeltaMovement();
      this.setPos(this.getX() + movement.x, this.getY() + movement.y, this.getZ() + movement.z);
   }
}
