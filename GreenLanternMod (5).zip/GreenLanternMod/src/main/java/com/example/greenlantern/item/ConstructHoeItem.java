package com.example.greenlantern.item;

import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;

public class ConstructHoeItem extends HoeItem {

   public ConstructHoeItem(Properties properties) {
      super(Tiers.DIAMOND, properties);
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
