package com.example.greenlantern.worldgen;

public final class CrashSite {
   public static final int MIN_X = -64;
   public static final int MAX_X = 36;
   public static final int MIN_Z = -22;
   public static final int MAX_Z = 26;
   public static final int LOW = -24;
   public static final int HIGH = 32;
   private static final double O_X = (double)7.0F;
   private static final double O_Y = 1.2;
   private static final double O_Z = (double)0.5F;
   private static final double P = 2.4;
   private static final double[][] ROT = multiply(multiply(rotationY(0.1), rotationZ(-0.23)), rotationX(-0.19));
   public static final double[] ABIN = toWorld(1.6, (double)0.0F, 0.6);
   public static final int FLOOR_Y = (int)Math.round(-1.0000000000000002);
   private static final int DEBRIS = 18;
   private static final int[][] DEBRIS_AT = new int[18][];
   private static final Part[] DEBRIS_PART = new Part[18];
   private static final int[][] LIGHTS = new int[3][];
   private static final int[][] STRIP = new int[5][];
   private static final int[][] CAMPFIRES = new int[2][];

   private CrashSite() {
   }

   public static Column column(int x, int z, int realTop, boolean grassy, boolean wet) {
      Column column = new Column(realTop);
      if (!wet) {
         terrain(column, x, z, grassy);
      }

      ship(column, x, z);

      for(int[] light : LIGHTS) {
         if (light[0] == x && light[1] == z) {
            for(int y = FLOOR_Y + 1; y < FLOOR_Y + 9; ++y) {
               if (column.filled(y)) {
                  column.set(y, CrashSite.Part.FROGLIGHT);
                  break;
               }
            }
         }
      }

      for(int[] strip : STRIP) {
         if (strip[0] == x && strip[1] == z) {
            column.set(FLOOR_Y + 1, strip[2] == 0 ? CrashSite.Part.MAGMA : (strip[2] == 1 ? CrashSite.Part.METAL : CrashSite.Part.POLISHED_BLACKSTONE));
            column.ship[FLOOR_Y + 1 - -24] = true;
            if (strip[2] == 0) {
               column.set(FLOOR_Y + 2, CrashSite.Part.FIRE);
            }
         }
      }

      if (!wet) {
         for(int[] campfire : CAMPFIRES) {
            if (campfire[0] == x && campfire[1] == z && !column.filled(column.top + 1)) {
               column.set(column.top, CrashSite.Part.HAY);
               column.set(column.top + 1, CrashSite.Part.CAMPFIRE);
            }
         }

         for(int y = -24; y < 31; ++y) {
            Part part = column.at(y);
            if ((part == CrashSite.Part.NETHERRACK || part == CrashSite.Part.MAGMA) && !column.filled(y + 1) && !column.isShip(y) && hash(x, y, z + 77) < (part == CrashSite.Part.NETHERRACK ? 0.7 : (double)0.25F)) {
               column.set(y + 1, CrashSite.Part.FIRE);
            }
         }
      }

      return column;
   }

   private static void terrain(Column column, int x, int z, boolean grassy) {
      int s = column.realTop;
      double trench = Double.NaN;
      int trenchRise = 0;
      if (x >= -60 && x < 0) {
         double t = clamp((double)(x + 60) / (double)60.0F, (double)0.0F, (double)1.0F);
         double half = lerp((double)3.0F, 6.4, t) + (vnoise((double)x / (double)4.0F, (double)0.0F, 9) - (double)0.5F) * 1.6;
         double depth = lerp(0.8, 3.1, t);
         double dz = ((double)z + (double)0.5F - sway((double)x)) / half;
         if (Math.abs(dz) < (double)1.0F) {
            trench = depth * Math.sqrt((double)1.0F - dz * dz) + (vnoise((double)x / (double)3.0F, (double)z / (double)3.0F, 4) - (double)0.5F) * 0.8;
         } else if (Math.abs(dz) < (double)1.0F + 2.6 / half) {
            trenchRise = Math.abs(dz) < (double)1.0F + 1.3 / half ? 2 : 1;
         }
      }

      double crater = Double.NaN;
      int craterRise = 0;
      if (x >= -12 && x < 26 && z >= -18 && z < 18) {
         double e = craterE(x, z);
         if (e < (double)1.0F) {
            crater = 4.6 * Math.pow((double)1.0F - e, 0.8) + (vnoise((double)x / (double)3.0F, (double)z / (double)3.0F, 6) - (double)0.5F) * 0.9;
         } else if (e < 1.45) {
            craterRise = (int)Math.round(2.2 * ((double)1.0F - (e - (double)1.0F) / 0.45));
         }
      }

      boolean carved = !Double.isNaN(trench) || !Double.isNaN(crater);
      boolean topGrass = grassy;
      if (carved) {
         int down = (Double.isNaN(trench) ? 0 : Math.max(0, (int)Math.round(trench))) + (Double.isNaN(crater) ? 0 : Math.max(0, (int)Math.round(crater)));
         int floor = s - down;

         for(int y = floor + 1; y < s + 4; ++y) {
            column.set(y, CrashSite.Part.AIR);
         }

         for(int y = floor - 2; y <= floor; ++y) {
            column.set(y, crashBlock(x, y, z, y == floor));
         }

         s = floor;
      } else {
         for(int rise : new int[]{trenchRise, craterRise}) {
            if (rise > 0) {
               for(int k = 1; k <= rise; ++k) {
                  column.set(s + k, k == rise && hash(x, z, 61) < 0.45 ? CrashSite.Part.GRASS : (hash(x, z + k, 62) < (double)0.5F ? CrashSite.Part.COARSE : CrashSite.Part.DIRT));
               }

               column.set(s, CrashSite.Part.DIRT);
               s += rise;
               topGrass = column.at(s) == CrashSite.Part.GRASS;
            }
         }

         double near = Math.min(craterE(x, z) - (double)1.0F, x < 0 ? Math.abs((double)z + (double)0.5F - sway((double)x)) / (double)9.0F - 0.6 : (double)9.0F);
         if (near < 0.9 && topGrass && vnoise((double)x / (double)2.5F, (double)z / (double)2.5F, 12) > 0.45 + near * 0.4) {
            column.set(s, hash(x, z, 63) < 0.12 ? CrashSite.Part.NETHERRACK : CrashSite.Part.COARSE);
         }
      }

      column.top = s;

      for(int i = 0; i < 18; ++i) {
         int[] at = DEBRIS_AT[i];
         if (at[1] == z) {
            if (at[0] == x) {
               column.set(s + 1, DEBRIS_PART[i]);
               if (at[3] == 1) {
                  column.set(s + 2, CrashSite.Part.LIGHT_GRAY);
               }
            } else if (at[2] == 1 && at[0] + 1 == x) {
               column.set(s + 1, DEBRIS_PART[i]);
            }
         }
      }

   }

   private static void ship(Column column, int x, int z) {
      if (x >= -20 && x < 32 && z >= -22 && z < 26) {
         int low = Integer.MAX_VALUE;

         for(int y = -10; y < 24; ++y) {
            Part part = shipCell(x, y, z);
            if (part != null) {
               column.set(y, part);
               if (part != CrashSite.Part.AIR) {
                  column.ship[y - -24] = true;
                  low = Math.min(low, y);
               }
            }
         }

         if (low != Integer.MAX_VALUE) {
            for(int y = low - 1; y > column.top && y > -24; --y) {
               if (!column.filled(y)) {
                  column.set(y, crashBlock(x, y, z, false));
               }
            }
         }

      }
   }

   static Part shipCell(int x, int y, int z) {
      double[] l = toLocal((double)x + (double)0.5F, (double)y + (double)0.5F, (double)z + (double)0.5F);
      Part part = null;
      if (within(l[0], l[1], l[2], (double)0.0F)) {
         if (within(l[0], l[1], l[2], 1.1)) {
            part = y > FLOOR_Y ? CrashSite.Part.AIR : (y == FLOOR_Y ? CrashSite.Part.POLISHED : CrashSite.Part.BLACK);
         } else {
            part = hullBlock(l[0], l[1], l[2], x, y, z);
            boolean breach = l[2] > (double)0.0F && l[0] > (double)2.0F && l[0] < (double)6.5F && y > FLOOR_Y && (long)y <= (long)(FLOOR_Y + 3) + Math.round(hash(x, z, 90) * (double)1.5F);
            if (breach) {
               part = CrashSite.Part.AIR;
            }
         }
      }

      if (part == null) {
         part = wingBlock(l[0], l[1], l[2]);
      }

      if (part == null) {
         part = finBlock(l[0], l[1], l[2]);
      }

      if (part == null) {
         part = engineBlock(l[0], l[1], l[2]);
      }

      return part;
   }

   private static double[] hull(double lx) {
      if (!(lx < (double)-13.0F) && !(lx > (double)15.5F)) {
         double cy = (double)0.0F;
         double w;
         double h;
         if (lx < (double)-9.0F) {
            double t = (lx + (double)13.0F) / (double)4.0F;
            w = 2.8 + 1.6 * t;
            h = 2.3 + 1.2 * t;
         } else if (lx < (double)4.0F) {
            w = 4.4;
            h = (double)3.5F;
         } else {
            double t = Math.min((double)1.0F, (lx - (double)4.0F) / (double)11.5F);
            w = 4.4 * ((double)1.0F - Math.pow(t, 1.6)) + 0.4 * t;
            h = (double)3.5F * ((double)1.0F - Math.pow(t, (double)1.25F)) + (double)0.5F * t;
            cy = -1.2 * Math.pow(t, 1.8);
         }

         return new double[]{w, h, cy};
      } else {
         return null;
      }
   }

   private static boolean within(double lx, double ly, double lz, double shrink) {
      double[] p = hull(lx);
      if (p == null) {
         return false;
      } else {
         double w = p[0] - shrink;
         double h = p[1] - shrink;
         if (!(w <= (double)0.0F) && !(h <= (double)0.0F)) {
            return Math.pow(Math.abs(lz) / w, 2.4) + Math.pow(Math.abs(ly - p[2]) / h, 2.4) <= (double)1.0F;
         } else {
            return false;
         }
      }
   }

   private static Part hullBlock(double lx, double ly, double lz, int wx, int wy, int wz) {
      double[] p = hull(lx);
      double rel = (ly - p[2]) / p[1];
      double side = Math.abs(lz) / p[0];
      double r = hash(wx, wy, wz);
      if (lx > (double)4.5F && lx < (double)11.0F && rel > 0.3 && side < (double)0.75F) {
         return lx > (double)6.0F && lx < (double)10.0F && r < 0.28 ? CrashSite.Part.AIR : CrashSite.Part.GLASS;
      } else if (lx > 13.2) {
         return CrashSite.Part.POLISHED;
      } else if ((lx > (double)8.0F || rel < -0.6) && r < 0.22) {
         return r < 0.1 ? CrashSite.Part.BLACK : CrashSite.Part.GRAY;
      } else {
         for(double ring : new double[]{(double)-8.5F, (double)-3.5F, (double)1.5F, (double)7.0F}) {
            if (Math.abs(lx - ring) < (double)0.5F) {
               return CrashSite.Part.LIGHT_GRAY;
            }
         }

         if (rel > -0.12 && rel < 0.18 && side > 0.55) {
            return CrashSite.Part.TILES;
         } else if (rel < -0.55) {
            return r < 0.3 ? CrashSite.Part.METAL : CrashSite.Part.LIGHT_GRAY;
         } else {
            return r < 0.08 ? CrashSite.Part.LIGHT_GRAY : CrashSite.Part.WHITE;
         }
      }
   }

   private static Part wingBlock(double lx, double ly, double lz) {
      boolean right = lz >= (double)0.0F;
      double root = (double)4.0F;
      double s = Math.abs(lz) - root;
      if (s < (double)-1.0F) {
         return null;
      } else if (right && s > (double)4.0F) {
         double a = 0.62;
         double dz = Math.abs(lz) - (root + (double)4.0F);
         double dy = ly + 0.6;
         double ss = dz * Math.cos(a) + dy * Math.sin(a);
         double yy = -dz * Math.sin(a) + dy * Math.cos(a);
         return wingFill(lx, right, (double)4.0F + ss, yy);
      } else {
         return wingFill(lx, right, s, ly + 0.6);
      }
   }

   private static Part wingFill(double lx, boolean right, double ss, double yy) {
      double span = right ? (double)11.5F : (double)8.5F;
      if (!(ss < (double)-1.0F) && !(ss > span) && !(Math.abs(yy) > (ss < (double)3.0F ? 0.9 : 0.62))) {
         double chord = Math.max((double)0.0F, ss);
         double te = (double)-6.5F + 0.12 * chord;
         double le = (double)2.5F - 0.62 * chord;
         if (!(lx < te) && !(lx > le)) {
            if (!right && ss > span - 1.6 * hash((int)Math.round(lx), 9, 81)) {
               return null;
            } else if (ss > span - 1.6) {
               return CrashSite.Part.POLISHED;
            } else if (lx > le - 1.1) {
               return CrashSite.Part.GRAY;
            } else {
               return ss > (double)2.0F && ss < (double)3.0F ? CrashSite.Part.LIGHT_GRAY : CrashSite.Part.WHITE;
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private static Part finBlock(double lx, double ly, double lz) {
      double t = ly - (double)3.0F;
      if (!(t < (double)-1.0F) && !(t > (double)11.5F)) {
         double le = (double)-5.0F - 0.55 * Math.max((double)0.0F, t);
         double te = (double)-12.5F - 0.1 * Math.max((double)0.0F, t);
         if (!(lx > le) && !(lx < te)) {
            if (Math.abs(lz) > (t < (double)1.5F ? 1.1 : 0.62)) {
               return null;
            } else if (t > (double)10.0F) {
               return CrashSite.Part.LIGHT_GRAY;
            } else if (t > 5.2 && t < 7.2 && lx < le - 1.2 && lx > te + 1.2) {
               return CrashSite.Part.CHISELED;
            } else {
               return !(lx > le - 1.1) && !(lx < te + 1.1) ? CrashSite.Part.TILES : CrashSite.Part.POLISHED;
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private static Part engineBlock(double lx, double ly, double lz) {
      if (!(lx < -16.2) && !(lx > (double)-11.0F)) {
         for(double ez : new double[]{-2.4, 2.4}) {
            double r = Math.hypot(lz - ez, ly + (double)1.0F);
            if (r <= 1.85) {
               if (lx < -15.4) {
                  return r < (double)1.0F ? CrashSite.Part.MAGMA : CrashSite.Part.BLACK;
               }

               return Math.abs(lx + (double)13.5F) < (double)0.5F ? CrashSite.Part.METAL : CrashSite.Part.GRAY;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   static Part crashBlock(int x, int y, int z, boolean top) {
      double r = hash(x, y * 7 + 3, z);
      if (top) {
         if (r < 0.07) {
            return CrashSite.Part.MAGMA;
         }

         if (r < 0.13) {
            return CrashSite.Part.NETHERRACK;
         }

         if (r < 0.16) {
            return CrashSite.Part.NYLIUM;
         }
      }

      double n = vnoise((double)x / 3.2, (double)z / 3.2 + (double)y * 0.7, 5);
      if (n < 0.3) {
         return CrashSite.Part.BLACKSTONE;
      } else if (n < 0.45) {
         return CrashSite.Part.COBBLED;
      } else if (n < 0.6) {
         return CrashSite.Part.BASALT;
      } else if (n < (double)0.75F) {
         return CrashSite.Part.COARSE;
      } else {
         return n < 0.86 ? CrashSite.Part.GRAVEL : CrashSite.Part.BLACKSTONE;
      }
   }

   public static double[] toWorld(double lx, double ly, double lz) {
      return new double[]{ROT[0][0] * lx + ROT[0][1] * ly + ROT[0][2] * lz + (double)7.0F, ROT[1][0] * lx + ROT[1][1] * ly + ROT[1][2] * lz + 1.2, ROT[2][0] * lx + ROT[2][1] * ly + ROT[2][2] * lz + (double)0.5F};
   }

   static double[] toLocal(double x, double y, double z) {
      double dx = x - (double)7.0F;
      double dy = y - 1.2;
      double dz = z - (double)0.5F;
      return new double[]{ROT[0][0] * dx + ROT[1][0] * dy + ROT[2][0] * dz, ROT[0][1] * dx + ROT[1][1] * dy + ROT[2][1] * dz, ROT[0][2] * dx + ROT[1][2] * dy + ROT[2][2] * dz};
   }

   private static double[][] rotationX(double a) {
      double c = Math.cos(a);
      double s = Math.sin(a);
      return new double[][]{{(double)1.0F, (double)0.0F, (double)0.0F}, {(double)0.0F, c, -s}, {(double)0.0F, s, c}};
   }

   private static double[][] rotationY(double a) {
      double c = Math.cos(a);
      double s = Math.sin(a);
      return new double[][]{{c, (double)0.0F, s}, {(double)0.0F, (double)1.0F, (double)0.0F}, {-s, (double)0.0F, c}};
   }

   private static double[][] rotationZ(double a) {
      double c = Math.cos(a);
      double s = Math.sin(a);
      return new double[][]{{c, -s, (double)0.0F}, {s, c, (double)0.0F}, {(double)0.0F, (double)0.0F, (double)1.0F}};
   }

   private static double[][] multiply(double[][] a, double[][] b) {
      double[][] out = new double[3][3];

      for(int i = 0; i < 3; ++i) {
         for(int j = 0; j < 3; ++j) {
            out[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j];
         }
      }

      return out;
   }

   static double sway(double x) {
      return 2.2 * Math.sin((x + (double)20.0F) / (double)17.0F);
   }

   static double craterE(int x, int z) {
      double a = ((double)x + (double)0.5F - (double)6.0F) / (double)14.0F;
      double b = ((double)z + (double)0.5F) / (double)11.5F;
      return a * a + b * b;
   }

   static double hash(int a, int b, int c) {
      int h = a * 374761393 ^ b * 668265263 ^ c * 1274126177;
      h = (h ^ h >>> 13) * 1103515245;
      return (double)((long)(h ^ h >>> 16) & 4294967295L) / (double)4.2949673E9F;
   }

   static double vnoise(double x, double z, int s) {
      int xi = (int)Math.floor(x);
      int zi = (int)Math.floor(z);
      double fx = x - (double)xi;
      double fz = z - (double)zi;
      double u = fx * fx * ((double)3.0F - (double)2.0F * fx);
      double v = fz * fz * ((double)3.0F - (double)2.0F * fz);
      double a = hash(xi, zi, s);
      double b = hash(xi + 1, zi, s);
      double c = hash(xi, zi + 1, s);
      double d = hash(xi + 1, zi + 1, s);
      return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
   }

   static double lerp(double a, double b, double t) {
      return a + (b - a) * t;
   }

   static double clamp(double v, double a, double b) {
      return Math.min(b, Math.max(a, v));
   }

   static {
      Part[] kinds = new Part[]{CrashSite.Part.WHITE, CrashSite.Part.LIGHT_GRAY, CrashSite.Part.METAL, CrashSite.Part.GRAY, CrashSite.Part.WHITE};

      for(int i = 0; i < 18; ++i) {
         int x = (int)Math.round(lerp((double)-54.0F, (double)-6.0F, hash(i, 1, 70)));
         int z = (int)Math.round(sway((double)x) + (hash(i, 2, 70) - (double)0.5F) * (double)7.0F);
         DEBRIS_AT[i] = new int[]{x, z, hash(i, 4, 70) < (double)0.5F ? 1 : 0, hash(i, 5, 70) < 0.3 ? 1 : 0};
         DEBRIS_PART[i] = kinds[(int)Math.floor(hash(i, 3, 70) * (double)kinds.length)];
      }

      int[] lightsAt = new int[]{-6, -2, 2};

      for(int i = 0; i < 3; ++i) {
         double[] p = toWorld((double)lightsAt[i], (double)0.0F, (double)0.0F);
         LIGHTS[i] = new int[]{(int)Math.floor(p[0]), (int)Math.floor(p[2])};
      }

      for(int lz = -2; lz <= 2; ++lz) {
         double[] p = toWorld((double)6.5F, (double)0.0F, (double)lz);
         STRIP[lz + 2] = new int[]{(int)Math.floor(p[0]), (int)Math.floor(p[2]), lz};
      }

      double[] engines = new double[]{-2.4, 2.4};

      for(int i = 0; i < 2; ++i) {
         double[] p = toWorld((double)-17.5F, (double)-1.0F, engines[i]);
         CAMPFIRES[i] = new int[]{(int)Math.floor(p[0]), (int)Math.floor(p[2])};
      }

   }

   public static enum Part {
      AIR,
      GRASS,
      DIRT,
      COARSE,
      GRAVEL,
      BLACKSTONE,
      BASALT,
      COBBLED,
      TILES,
      POLISHED,
      POLISHED_BLACKSTONE,
      CHISELED,
      MAGMA,
      NETHERRACK,
      NYLIUM,
      WHITE,
      LIGHT_GRAY,
      GRAY,
      BLACK,
      METAL,
      GLASS,
      FROGLIGHT,
      FIRE,
      CAMPFIRE,
      HAY;

      // $FF: synthetic method
      private static Part[] $values() {
         return new Part[]{AIR, GRASS, DIRT, COARSE, GRAVEL, BLACKSTONE, BASALT, COBBLED, TILES, POLISHED, POLISHED_BLACKSTONE, CHISELED, MAGMA, NETHERRACK, NYLIUM, WHITE, LIGHT_GRAY, GRAY, BLACK, METAL, GLASS, FROGLIGHT, FIRE, CAMPFIRE, HAY};
      }
   }

   public static final class Column {
      private final Part[] cells = new Part[56];
      private final boolean[] ship = new boolean[56];
      private final int realTop;
      private int top;

      Column(int realTop) {
         this.realTop = realTop;
         this.top = realTop;
      }

      public Part at(int y) {
         return y >= -24 && y < 32 ? this.cells[y - -24] : null;
      }

      void set(int y, Part part) {
         if (y >= -24 && y < 32) {
            this.cells[y - -24] = part;
         }

      }

      boolean isShip(int y) {
         return y >= -24 && y < 32 && this.ship[y - -24];
      }

      boolean filled(int y) {
         Part part = this.at(y);
         return part != null ? part != CrashSite.Part.AIR : y <= this.realTop;
      }

      public int top() {
         return this.top;
      }
   }
}
