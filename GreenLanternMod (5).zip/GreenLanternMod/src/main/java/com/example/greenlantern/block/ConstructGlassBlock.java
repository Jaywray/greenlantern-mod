package com.example.greenlantern.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.HalfTransparentBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class ConstructGlassBlock extends HalfTransparentBlock {

   public ConstructGlassBlock(BlockBehaviour.Properties properties) {
      super(properties);
   }

   @Override
   public VoxelShape getVisualShape(BlockState state, BlockGetter reader, BlockPos pos, CollisionContext context) {
      return Shapes.empty();
   }

   @Override
   public float getShadeBrightness(BlockState state, BlockGetter reader, BlockPos pos) {
      return 1.0F;
   }

   @Override
   public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
      return true;
   }

   @Override
   public boolean skipRendering(BlockState state, BlockState adjacentBlockState, Direction side) {
      return adjacentBlockState.is(this) || super.skipRendering(state, adjacentBlockState, side);
   }
}
