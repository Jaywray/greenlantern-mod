package com.example.greenlantern.ability;

import net.minecraft.network.chat.Component;

public enum Ability {
   SHIELD(0, "shield"),
   LASER(1, "laser"),
   MINIGUN(2, "minigun"),
   FLIGHT(3, "flight"),
   RING_LIGHT(4, "ring_light"),
   RING_OATH(5, "ring_oath"),
   TORNADO(6, "tornado"),
   CAPTURE_BUBBLE(7, "capture_bubble");

   private final int index;
   private final String id;

   Ability(int index, String id) {
      this.index = index;
      this.id = id;
   }

   public int getIndex() {
      return this.index;
   }

   public String getId() {
      return this.id;
   }

   public Component getDescription() {
      return Component.translatable("ability.greenlantern." + this.id);
   }

   // Safely translates integer values back into matching Enum selections
   public static Ability fromIndex(int index) {
      for (Ability ability : values()) {
         if (ability.getIndex() == index) {
            return ability;
         }
      }
      return SHIELD; // Safe fallback selection
   }
}
