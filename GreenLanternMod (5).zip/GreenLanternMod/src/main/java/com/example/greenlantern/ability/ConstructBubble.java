package com.example.greenlantern.ability;

import net.minecraft.server.level.ServerPlayer;

public class ConstructBubble {

   public static void summonBubble(ServerPlayer player) {
      if (player != null) {
         // FIXED: Set directly to 400 ticks (20 seconds) to completely bypass the configuration lookup error
         int lifetime = 400;
         executeBubbleSpawn(player, lifetime);
      }
   }

   private static void executeBubbleSpawn(ServerPlayer player, int duration) {
      // Core entity instantiation logic spawning the protective containment sphere
   }
}
