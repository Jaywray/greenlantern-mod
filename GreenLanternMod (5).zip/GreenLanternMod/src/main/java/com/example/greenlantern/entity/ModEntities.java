package com.example.greenlantern.entity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
   // The modern NeoForge 1.21.1 way of building an Entity Type registry
   public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = 
       DeferredRegister.create(Registries.ENTITY_TYPE, "greenlantern");

   // RegistryObjects are now converted over to modern DeferredHolders
   public static final DeferredHolder<EntityType<?>, EntityType<PulseShotEntity>> PULSE_SHOT = 
       ENTITY_TYPES.register("pulse_shot", () -> EntityType.Builder.<PulseShotEntity>of(PulseShotEntity::new, MobCategory.MISC)
           .sized(0.4F, 0.4F)
           .clientTrackingRange(8)
           .updateInterval(2)
           .build("pulse_shot"));

   public static final DeferredHolder<EntityType<?>, EntityType<ShieldConstructEntity>> SHIELD_CONSTRUCT = 
       ENTITY_TYPES.register("shield_construct", () -> EntityType.Builder.<ShieldConstructEntity>of(ShieldConstructEntity::new, MobCategory.MISC)
           .sized(0.5F, 0.5F)
           .clientTrackingRange(10)
           .updateInterval(20)
           .noSummon()
           .fireImmune()
           .build("shield_construct"));

   public static final DeferredHolder<EntityType<?>, EntityType<RiotShieldEntity>> RIOT_SHIELD = 
       ENTITY_TYPES.register("riot_shield", () -> EntityType.Builder.<RiotShieldEntity>of(RiotShieldEntity::new, MobCategory.MISC)
           .sized(1.3F, 2.4F)
           .clientTrackingRange(10)
           .updateInterval(1)
           .noSummon()
           .fireImmune()
           .build("riot_shield"));

   public static final DeferredHolder<EntityType<?>, EntityType<TornadoEntity>> TORNADO = 
       ENTITY_TYPES.register("tornado", () -> EntityType.Builder.<TornadoEntity>of(TornadoEntity::new, MobCategory.MISC)
           .sized(2.0F, 14.0F)
           .clientTrackingRange(10)
           .updateInterval(5)
           .noSummon()
           .fireImmune()
           .build("tornado"));

   public static final DeferredHolder<EntityType<?>, EntityType<MinigunBoltEntity>> MINIGUN_BOLT = 
       ENTITY_TYPES.register("minigun_bolt", () -> EntityType.Builder.<MinigunBoltEntity>of(MinigunBoltEntity::new, MobCategory.MISC)
           .sized(0.2F, 0.2F)
           .clientTrackingRange(6)
           .updateInterval(10)
           .setShouldReceiveVelocityUpdates(false)
           .noSummon()
           .fireImmune()
           .build("minigun_bolt"));

   public static final DeferredHolder<EntityType<?>, EntityType<LaserBeamEntity>> LASER_BEAM = 
       ENTITY_TYPES.register("laser_beam", () -> EntityType.Builder.<LaserBeamEntity>of(LaserBeamEntity::new, MobCategory.MISC)
           .sized(0.5F, 0.5F)
           .clientTrackingRange(10)
           .updateInterval(1)
           .noSummon()
           .fireImmune()
           .build("laser_beam"));

   public static final DeferredHolder<EntityType<?>, EntityType<AbinSurEntity>> ABIN_SUR = 
       ENTITY_TYPES.register("abin_sur", () -> EntityType.Builder.<AbinSurEntity>of(AbinSurEntity::new, MobCategory.MISC)
           .sized(1.4F, 0.5F)
           .clientTrackingRange(10)
           .noSummon()
           .build("abin_sur"));

   public static final DeferredHolder<EntityType<?>, EntityType<CarrierBubbleEntity>> CARRIER_BUBBLE = 
       ENTITY_TYPES.register("carrier_bubble", () -> EntityType.Builder.<CarrierBubbleEntity>of(CarrierBubbleEntity::new, MobCategory.MISC)
           .sized(1.4F, 2.2F)
           .clientTrackingRange(10)
           .updateInterval(1)
           .noSummon()
           .fireImmune()
           .noSave()
           .build("carrier_bubble"));

   public static final DeferredHolder<EntityType<?>, EntityType<TrapBubbleEntity>> TRAP_BUBBLE = 
       ENTITY_TYPES.register("trap_bubble", () -> EntityType.Builder.<TrapBubbleEntity>of(TrapBubbleEntity::new, MobCategory.MISC)
           .sized(1.0F, 1.0F)
           .clientTrackingRange(10)
           .updateInterval(1)
           .noSummon()
           .fireImmune()
           .noSave()
           .build("trap_bubble"));

   // Triggers dynamic living attribute definitions on the updated event loop listener
   public static void onAttributes(EntityAttributeCreationEvent event) {
      event.put(ABIN_SUR.get(), AbinSurEntity.createAttributes().build());
   }

   // Simple initialization method to cleanly hook straight into your main GreenLanternMod boot bus
   public static void register(IEventBus eventBus) {
       ENTITY_TYPES.register(eventBus);
   }
}
