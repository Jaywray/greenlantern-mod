#version 150

#moj_import <greenlantern:pulse_common.glsl>

uniform sampler2D DepthSampler;
uniform vec2 ScreenSize;
uniform mat4 ProjMat;
uniform vec3 VolumeCamera;
uniform float VolumeTime;
uniform float VolumePass;
uniform float SmokeSize;
uniform float SmokeRise;
uniform float SmokeThick;
uniform float SmokeLow;
uniform float SmokeHeat;
uniform float SmokeFlash;
uniform vec3 SmokeBound;
uniform vec3 SmokeBurst;

in vec3 localPos;
in vec3 viewPos;

out vec4 fragColor;

float smoke(vec3 p, out float n) {
    vec3 s = p / SmokeSize;
    float big = snoise(s * 2.3 + vec3(0.0, -VolumeTime * 0.10, VolumeTime * 0.06));
    vec3 q = (p - vec3(0.0, SmokeRise, 0.0)) / vec3(SmokeSize, SmokeSize * 0.62, SmokeSize);
    float reach = 1.0 - length(q) + 0.32 * big;
    if (reach <= -0.16 && (SmokeLow <= 0.0 || length(p.xz) / SmokeSize >= 1.53)) {
        n = 0.6 * big;
        return 0.0;
    }
    float mid = snoise(p * 0.55 + vec3(VolumeTime * 0.16, -VolumeTime * 0.28, 3.7));
    n = 0.6 * big + 0.4 * mid;
    float dome = smoothstep(0.0, 0.3, reach + 0.14 * mid);
    float low = SmokeLow * exp(-max(p.y, 0.0) / (0.3 + 0.12 * SmokeSize))
            * smoothstep(1.3, 0.75, length(p.xz) / SmokeSize + 0.2 * mid);
    float d = max(dome, low * 0.75);
    d *= 1.0 - 0.5 * smoothstep(0.3, 1.2, p.y / (SmokeRise + SmokeSize * 0.62));
    d *= smoothstep(-1.5, 0.0, p.y);
    return d * (0.75 + 0.3 * n);
}

void main() {
    bool lightPass = VolumePass > 0.5;
    vec3 C = VolumeCamera;
    vec3 V = normalize(localPos - C);
    vec3 mid = vec3(0.0, SmokeRise, 0.0);
    vec3 o = (C - mid) / SmokeBound;
    vec3 d = V / SmokeBound;
    float a = dot(d, d);
    float b = dot(o, d);
    float disc = b * b - a * (dot(o, o) - 1.0);
    if (disc <= 0.0 || SmokeThick <= 0.001) {
        discard;
    }
    float sq = sqrt(disc);
    float t0 = max((-b - sq) / a, 0.0);
    float t1 = min((-b + sq) / a, sceneDistance(DepthSampler, ScreenSize, ProjMat, viewPos));
    if (t1 <= t0) {
        discard;
    }
    int steps = lightPass ? 20 : 10;
    float dt = (t1 - t0) / float(steps);
    float jitter = dither(gl_FragCoord.xy);
    float sigma = SmokeThick * 1.6 / SmokeSize;
    float trans = 1.0;
    vec3 emit = vec3(0.0);
    for (int i = 0; i < 20; i++) {
        if (i >= steps) {
            break;
        }
        vec3 p = C + V * (t0 + dt * (float(i) + jitter));
        float n;
        float dens = smoke(p, n) * sigma;
        if (lightPass) {
            vec3 h = p - SmokeBurst;
            float heart = exp(-dot(h, h) / (0.12 * SmokeSize * SmokeSize + 0.4));
            float energy = clamp(SmokeHeat * (0.6 + 0.7 * heart) + 0.2 * n, 0.0, 1.0);
            vec3 col = mix(vec3(0.05, 0.24, 0.14), energyColor(n * 1.4 + 0.1) * 1.3, energy) * (0.8 + 0.4 * n);
            col *= 1.0 + 0.35 * exp(-max(p.y, 0.0) / 1.2);
            col += vec3(0.45, 0.87, 0.54) * SmokeFlash * heart * 2.0;
            emit += col * dens * dt * trans;
        }
        trans *= exp(-dens * dt);
        if (trans < 0.002) {
            break;
        }
    }
    if (lightPass) {
        fragColor = vec4(emit, 1.0);
    } else {
        fragColor = vec4(trans * mix(vec3(1.0), RIOT_GLASS, 1.0 - trans), 1.0);
    }
}
