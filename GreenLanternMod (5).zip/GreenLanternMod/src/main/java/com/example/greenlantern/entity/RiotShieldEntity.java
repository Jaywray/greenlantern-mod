package com.example.greenlantern.entity;

import com.example.greenlantern.ability.Ability;
import com.example.greenlantern.ability.AbilityHandler;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RiotShieldEntity extends Entity {

   private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(RiotShieldEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Boolean> CLOSING = SynchedEntityData.defineId(RiotShieldEntity.class, EntityDataSerializers.BOOLEAN);

   private static final Map<UUID, Long> HOLD_UNTIL = new HashMap<>();
   private static final Map<UUID, UUID> SHIELDS = new HashMap<>();

   public RiotShieldEntity(EntityType<?> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public static void toggleShieldDeployment(ServerPlayer player, RiotShieldEntity shield) {
      if (player == null) return;
      Level level = player.level();

      // FIXED: Replaced legacy obfuscated world time and UUID access methods
      long gameTime = level.getGameTime();
      UUID playerUuid = player.getUUID();

      if (shield == null) {
         HOLD_UNTIL.put(playerUuid, gameTime + 6L);
         RiotShieldEntity newShield = new RiotShieldEntity(player.getType(), level);
         newShield.entityData.set(OWNER_ID, player.getId());
         newShield.setPos(player.getX(), player.getY(), player.getZ());

         // FIXED: Introduced entity to the layer pool using modern addFreshEntity layout
         level.addFreshEntity(newShield);
         SHIELDS.put(playerUuid, newShield.getUUID());

         level.playSound(null, player.getX(), player.getY(), player.getZ(),
                 SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0F, 1.0F);
      } else {
         HOLD_UNTIL.remove(playerUuid);
         if (!shield.isClosing() && shield.level() instanceof ServerLevel) {
            shield.entityData.set(CLOSING, true);
            // FIXED: Direct fallback cooldown parameter injection bypassing configuration loops
            AbilityHandler.executeAbility(player, Ability.SHIELD);
         }
      }
   }

   public boolean isClosing() {
      return this.entityData.get(CLOSING);
   }

   public int getOwnerId() {
      return this.entityData.get(OWNER_ID);
   }

   @Override
   public void tick() {
      super.tick();
      if (!this.level().isClientSide() && isClosing()) {
         this.discard();
      }
   }

   @Override
   protected void defineSynchedData(SynchedEntityData.Builder builder) {
      builder.define(OWNER_ID, 0);
      builder.define(CLOSING, false);
   }

   @Override
   protected void readAdditionalSaveData(CompoundTag tag) {
      if (tag.contains("OwnerId")) this.entityData.set(OWNER_ID, tag.getInt("OwnerId"));
      if (tag.contains("Closing")) this.entityData.set(CLOSING, tag.getBoolean("Closing"));
   }

   @Override
   protected void addAdditionalSaveData(CompoundTag tag) {
      tag.putInt("OwnerId", this.entityData.get(OWNER_ID));
      tag.putBoolean("Closing", this.entityData.get(CLOSING));
   }
}
