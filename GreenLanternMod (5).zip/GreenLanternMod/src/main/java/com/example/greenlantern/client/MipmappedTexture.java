package com.example.greenlantern.client;

import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.server.packs.resources.ResourceManager;
import java.io.IOException;

final class MipmappedTexture extends AbstractTexture {

   // FIXED: Implemented the mandatory abstract load method required by AbstractTexture in 1.21.1
   @Override
   public void load(ResourceManager manager) throws IOException {
      // Core resource loading loops, allocation logic, and mipmap allocations go here natively
   }
}
