package com.example.greenlantern.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {

    // Modern 1.21.1 NeoForge deferred tab registry handler pipeline
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "greenlantern");

    // FIXED: Creates a beautiful, customized "Green Lantern Corps" tab panel inside the inventory menu
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> GREEN_LANTERN_TAB =
            CREATIVE_MODE_TABS.register("greenlantern_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.greenlantern_tab"))
                    .icon(() -> new ItemStack(ModBlocks.POWER_BATTERY.get())) // Sets the battery as the icon
                    .displayItems((parameters, output) -> {
                        // Natively injects all your custom mod items into the visible creative slot grid
                        output.accept(ModBlocks.POWER_BATTERY.get());
                        output.accept(ModBlocks.RING_LIGHT.get());
                    })
                    .build());

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
