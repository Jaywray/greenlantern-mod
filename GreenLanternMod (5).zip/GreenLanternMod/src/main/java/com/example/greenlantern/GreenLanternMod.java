package com.example.greenlantern;

import com.example.greenlantern.registry.ModBlocks;
import com.example.greenlantern.registry.ModCreativeTabs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod("greenlantern")
public class GreenLanternMod {

   public GreenLanternMod(IEventBus modEventBus) {
      // Registers blocks and creative inventories natively into the live game launch sequence
      ModBlocks.register(modEventBus);
      ModCreativeTabs.register(modEventBus);
   }
}
