package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;

public class MinigunModel<T extends LivingEntity> extends HumanoidModel<T> {

   public MinigunModel(ModelPart root) {
      super(root);
   }

   public static void renderCustomMinigunQuads(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
      PoseStack.Pose lastPose = poseStack.last();

      // FIXED: Replaced the massive chain of legacy obfuscated m_ methods with clean 1.21.1 standard vertex builder parameters
      buffer.addVertex(lastPose, -0.2F, 0.0F, -0.2F)
              .setColor(red, green, blue, alpha)
              .setUv(0.0F, 0.0F)
              .setOverlay(packedOverlay)
              .setLight(packedLight)
              .setNormal(lastPose, 0.0F, 1.0F, 0.0F);

      buffer.addVertex(lastPose, 0.2F, 1.0F, 0.2F)
              .setColor(red, green, blue, alpha)
              .setUv(1.0F, 1.0F)
              .setOverlay(packedOverlay)
              .setLight(packedLight)
              .setNormal(lastPose, 0.0F, 1.0F, 0.0F);
   }
}
