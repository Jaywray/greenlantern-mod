package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import java.io.IOException;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PulseShaders {

   private static ShaderInstance pulseShader;

   @SubscribeEvent
   public static void onRegisterShaders(RegisterShadersEvent event) {
      try {
         // FIXED: Replaced legacy string mode conversions with native 1.21.1 DefaultVertexFormat specifications
         event.registerShader(new ShaderInstance(event.getResourceProvider(),
                         net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("greenlantern", "pulse"),
                         DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP),
                 shader -> pulseShader = shader
         );
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public static ShaderInstance getPulseShader() {
      return pulseShader;
   }
}
