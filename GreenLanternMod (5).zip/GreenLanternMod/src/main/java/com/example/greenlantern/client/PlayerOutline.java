package com.example.greenlantern.client;

import net.minecraft.world.entity.player.Player;
import java.util.HashMap;
import java.util.Map;

public class PlayerOutline {

   private static final Map<Integer, Fade> FADES = new HashMap<>();

   // Processes outline tracking metrics using clean version-independent primitive keys
   public static void updatePlayerOutlineFade(Player player) {
      if (player == null) return;

      // FIXED: Replaced legacy obfuscated m_19879_() call with clean, modern player.getId() logic
      Fade fade = FADES.get(player.getId());

      if (fade != null) {
         fade.tick();
         if (fade.isExpired()) {
            FADES.remove(player.getId());
         }
      }
   }

   public static class Fade {
      private int ticksLeft = 20;

      public void tick() {
         if (this.ticksLeft > 0) {
            this.ticksLeft--;
         }
      }

      public boolean isExpired() {
         return this.ticksLeft <= 0;
      }
   }
}
