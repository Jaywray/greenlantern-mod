package com.example.greenlantern.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class AbinSurEntity extends PathfinderMob {

   private int crashSiteRouteIndex = 0;

   public AbinSurEntity(EntityType<? extends PathfinderMob> type, Level level) {
      super(type, level);
   }

   @Override
   protected void registerGoals() {
      this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 8.0F));
      this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
   }

   public static AttributeSupplier.Builder createAttributes() {
      return PathfinderMob.createMobAttributes()
              .add(Attributes.MAX_HEALTH, 20.0D)
              .add(Attributes.MOVEMENT_SPEED, 0.25D);
   }

   // Version-independent routing method replacing the missing inner class layout
   public void setCrashSiteRoute(int routeId) {
      this.crashSiteRouteIndex = routeId;
   }

   public int getCrashSiteRoute() {
      return this.crashSiteRouteIndex;
   }
}
