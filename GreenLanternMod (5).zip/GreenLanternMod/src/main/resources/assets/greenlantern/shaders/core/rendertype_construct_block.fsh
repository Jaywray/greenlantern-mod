#version 150

#moj_import <greenlantern:pulse_common.glsl>
#moj_import <greenlantern:construct_form.glsl>

uniform float ConstructTime;
uniform float ConstructPass;

in vec3 gunPos;
in vec4 facePos;
in vec3 shape;
in vec3 surfaceNormal;
in vec3 viewPos;

out vec4 fragColor;

const vec3 EDGE_GLOW = vec3(0.30, 0.78, 0.50);

void main() {
    float t = ConstructTime;
    bool light = ConstructPass > 0.5;
    float amount = shape.x;
    float heat = shape.z;

    ivec3 cell = ivec3(floor(gunPos / 1.6 + vec3(0.137, 0.291, 0.073)));
    float centerZ = (float(cell.z) + 0.5 - 0.073) * 1.6;
    float shown = formShown(cell, clamp((23.6 - centerZ) / 30.1, 0.0, 1.0));
    if (shown < 0.0) {
        discard;
    }
    float band = exp(-shown / 0.08);
    if (formRand(cell, 29u) < Dissolve) {
        discard;
    }

    if (shape.y > 0.5) {
        float throb = 0.85 + 0.15 * sin(t * 9.0 + gunPos.z);
        fragColor = light ? vec4(EDGE_GLOW * (amount * throb * 0.8 * (1.0 + 0.6 * heat) + 0.45 * band + 0.6 * Dissolve), 1.0)
                : vec4(1.0);
        return;
    }

    vec3 p = gunPos * 0.38 + vec3(0.0, 0.0, -t * (0.5 + 3.0 * heat));
    vec3 w = p * 0.5 + vec3(0.0, t * 0.08, 0.0);
    vec2 warp = vec2(fbm2(w), fbm2(w + vec3(5.2, 1.3, 2.7))) * 0.9;
    vec3 q = p + vec3(warp, 0.0);
    float edgeDist = min(min(facePos.x, facePos.z - facePos.x), min(facePos.y, facePos.w - facePos.y));
    float edge = exp(-max(edgeDist, 0.0) / 0.16);

    if (!light) {
        float trans = exp(-mix(0.5, 2.0, amount) * energyDensity(fbm2(q)));
        vec3 glass = RIOT_GLASS * mix(trans, trans * 0.7, edge);
        fragColor = vec4(mix(glass, vec3(1.0), clamp(0.3 * band + Dissolve, 0.0, 1.0)), 1.0);
        return;
    }

    float n = fbm3(q);
    vec3 c = energyColor(n);
    float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
    c += RIOT_STRAND * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
    c *= 0.5 * (0.6 + 0.4 * amount) * (1.0 + 0.25 * heat);
    c += EDGE_GLOW * (0.4 + 0.15 * heat) * edge;
    float facing = abs(dot(normalize(surfaceNormal), normalize(-viewPos)));
    c += RIOT_SHEEN * 0.22 * pow(1.0 - facing, 3.0);
    c *= 0.95 + 0.1 * snoise(gunPos * 9.0);
    c += EDGE_GLOW * (0.45 * band + 0.6 * Dissolve);
    fragColor = vec4(c, 1.0);
}
