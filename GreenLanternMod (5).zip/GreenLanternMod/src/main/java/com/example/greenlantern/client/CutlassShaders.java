package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import java.io.IOException;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CutlassShaders {

   private static ShaderInstance cutlassShader;

   @SubscribeEvent
   public static void onRegisterShaders(RegisterShadersEvent event) {
      try {
         // FIXED: Replaced raw layout string fields with a native 1.21.1 DefaultVertexFormat reference matrix
         event.registerShader(new ShaderInstance(event.getResourceProvider(),
                         net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("greenlantern", "cutlass"),
                         DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP),
                 shader -> cutlassShader = shader
         );
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public static ShaderInstance getCutlassShader() {
      return cutlassShader;
   }
}
