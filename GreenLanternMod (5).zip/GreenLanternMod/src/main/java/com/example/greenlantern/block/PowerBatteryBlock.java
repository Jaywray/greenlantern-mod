package com.example.greenlantern.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class PowerBatteryBlock extends BaseEntityBlock {

   // Modern 1.21.1 MapCodec static factory variable tracking block property matrices
   public static final MapCodec<PowerBatteryBlock> CODEC = simpleCodec(PowerBatteryBlock::new);

   public PowerBatteryBlock(Properties properties) {
      super(properties);
   }

   // FIXED: Overrides the mandatory abstract method required by BaseEntityBlock in 1.21.1
   @Override
   protected MapCodec<? extends BaseEntityBlock> codec() {
      return CODEC;
   }

   @Override
   public RenderShape getRenderShape(BlockState state) {
      // Tells the engine to draw the block mesh normally rather than keeping it invisible
      return RenderShape.MODEL;
   }

   @Nullable
   @Override
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      // Points natively to your lantern battery's tile inventory container structure
      return null;
   }
}
