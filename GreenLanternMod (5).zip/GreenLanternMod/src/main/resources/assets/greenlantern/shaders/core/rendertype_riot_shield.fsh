#version 150

uniform vec3 ShieldCamera;
uniform float ShieldTime;
uniform float ShieldFade;
uniform float ShieldHit;
uniform float ShieldSeeThrough;
uniform float ShieldPass;

in vec3 shieldPos;
in vec3 shieldNormal;

out vec4 fragColor;

const float HALF_THICK = 0.06;
const vec2 OUTLINE[11] = vec2[](
    vec2(-0.351, 0.0), vec2(0.351, 0.0), vec2(0.446, 0.13), vec2(0.586, 1.751), vec2(0.432, 1.751),
    vec2(0.297, 2.4), vec2(-0.297, 2.4), vec2(-0.432, 1.751), vec2(-0.586, 1.751), vec2(-0.446, 0.13),
    vec2(-0.351, 0.0));

vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 permute(vec4 x) { return mod289(((x * 34.0) + 1.0) * x); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v) {
    const vec2 C = vec2(1.0 / 6.0, 1.0 / 3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i);
    vec4 p = permute(permute(permute(
            i.z + vec4(0.0, i1.z, i2.z, 1.0))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0))
            + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ * ns.x + ns.yyyy;
    vec4 y = y_ * ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0) * 2.0 + 1.0;
    vec4 s1 = floor(b1) * 2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}

float fbm2(vec3 p) {
    return 0.6 * snoise(p) + 0.3 * snoise(p * 2.03 + vec3(1.7, 9.2, 3.1));
}

float fbm3(vec3 p) {
    float s = 0.5 * snoise(p);
    p = p * 2.03 + vec3(1.7, 9.2, 3.1);
    s += 0.25 * snoise(p);
    p = p * 2.01 + vec3(4.1, 2.3, 7.7);
    s += 0.125 * snoise(p);
    return s * 1.6;
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec2 hash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453);
}

float cellEdge(vec2 p) {
    vec2 ip = floor(p);
    vec2 fp = fract(p);
    vec2 nearest = vec2(0.0);
    vec2 nearestCell = vec2(0.0);
    float best = 8.0;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2 g = vec2(float(i), float(j));
            vec2 r = g + hash2(ip + g) - fp;
            float d = dot(r, r);
            if (d < best) {
                best = d;
                nearest = r;
                nearestCell = g;
            }
        }
    }
    float edge = 8.0;
    for (int j = -2; j <= 2; j++) {
        for (int i = -2; i <= 2; i++) {
            vec2 g = nearestCell + vec2(float(i), float(j));
            vec2 r = g + hash2(ip + g) - fp;
            vec2 between = r - nearest;
            if (dot(between, between) > 0.00001) {
                edge = min(edge, dot(0.5 * (nearest + r), normalize(between)));
            }
        }
    }
    return edge;
}

float edgeDistance(vec2 p) {
    float d = 10.0;
    for (int i = 0; i < 10; i++) {
        vec2 a = OUTLINE[i];
        vec2 ab = OUTLINE[i + 1] - a;
        float k = clamp(dot(p - a, ab) / dot(ab, ab), 0.0, 1.0);
        d = min(d, length(p - a - ab * k));
    }
    return d;
}

vec2 flowWarp(vec2 p, float t) {
    vec3 a = vec3(p * 0.85, t * 0.05);
    return vec2(fbm2(a + vec3(0.0, -t * 0.06, 0.0)), fbm2(a + vec3(5.2, 1.3 - t * 0.05, 2.7))) * 0.9;
}

vec3 energySpace(vec3 p, vec2 warp, float t) {
    return vec3(p.x * 1.7 + warp.x, (p.y - t * 0.16) * 1.5 + warp.y, p.z * 5.0 + t * 0.05);
}

void main() {
    float t = ShieldTime;
    vec3 V = normalize(shieldPos - ShieldCamera);
    vec3 N = normalize(shieldNormal);
    if (dot(N, V) > 0.0) {
        discard;
    }
    float fres = pow(1.0 - abs(dot(N, V)), 3.0);
    bool side = abs(N.z) < 0.9;
    bool light = ShieldPass > 0.5;

    float maxL = side ? 0.12 : 0.3;
    float L = maxL;
    if (abs(V.z) > 0.001) {
        float zEnd = V.z > 0.0 ? HALF_THICK : -HALF_THICK;
        L = clamp((zEnd - shieldPos.z) / V.z, 0.0, maxL);
    }
    float thick = 2.0 * HALF_THICK;
    vec2 warp = flowWarp(shieldPos.xy, t);
    float absorb = mix(4.5, 0.5, ShieldSeeThrough);

    int steps = light ? (ShieldSeeThrough > 0.5 ? 3 : 5) : 2;
    float dt = L / float(steps);
    float trans = 1.0;
    vec3 emit = vec3(0.0);
    for (int i = 0; i < 5; i++) {
        if (i >= steps) {
            break;
        }
        vec3 p = shieldPos + V * (dt * (float(i) + 0.5));
        vec3 q = energySpace(p, warp, t);
        float n;
        if (light) {
            n = fbm3(q);
            float glow = smoothstep(-0.05, 0.5, n);
            vec3 c = mix(vec3(0.06, 0.33, 0.18), vec3(0.27, 0.72, 0.42), glow) + vec3(0.18, 0.15, 0.12) * glow * glow * glow;
            float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
            c += vec3(0.15, 0.40, 0.26) * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
            emit += c * (dt / thick) * mix(1.0, trans, 0.35);
        } else {
            n = fbm2(q);
        }
        float dens = clamp(0.6 + 0.8 * n, 0.15, 1.4);
        trans *= exp(-absorb * dens * dt / thick);
    }

    if (!light) {
        trans = mix(trans, trans * 0.5, fres);
        vec3 glass = mix(vec3(0.46, 0.86, 0.62), vec3(0.70, 0.93, 0.80), ShieldSeeThrough) * trans;
        fragColor = vec4(mix(vec3(1.0), glass, ShieldFade), 1.0);
        return;
    }

    emit *= 0.8 + 0.35 * max(dot(N, normalize(vec3(0.25, 0.65, 0.7))), 0.0);
    if (!side) {
        vec2 sp = shieldPos.xy;
        float crackMask = smoothstep(0.2, 0.55, snoise(vec3(sp * 1.2, 3.0 + t * 0.015)));
        if (crackMask > 0.0) {
            float e = cellEdge(sp * 3.6 + warp * 0.25);
            emit += vec3(0.20, 0.62, 0.38) * (1.0 - smoothstep(0.0, 0.022, e)) * crackMask;
        }
    }
    float ed = edgeDistance(shieldPos.xy);
    emit += vec3(0.10, 0.40, 0.25) * exp(-ed / 0.012) * (1.0 + 1.5 * ShieldHit);
    if (side) {
        emit *= vec3(0.75, 0.88, 1.12);
    }
    emit += vec3(0.40, 0.62, 0.58) * fres * 0.4;
    emit *= 0.95 + 0.1 * snoise(shieldPos * 70.0);
    float glint = step(0.9988, hash(floor(shieldPos.xy * 110.0) + floor(t * 5.0) * 17.0));
    emit += vec3(0.30, 0.70, 0.45) * glint * 0.3;
    emit *= (1.0 + 0.05 * sin(t * 1.7)) * (1.0 + 0.6 * ShieldHit) * mix(1.0, 0.35, ShieldSeeThrough);
    fragColor = vec4(emit * ShieldFade, 1.0);
}
