package com.example.greenlantern.client;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.Projectile;

public class PulseShotRenderer extends EntityRenderer<Projectile> {

   // FIXED: Replaced private constructor initialization with modern 1.21.1 static path lookup factory
   private static final ResourceLocation GLOW = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/effect/pulse_glow.png");

   public PulseShotRenderer(EntityRendererProvider.Context context) {
      super(context);
   }

   @Override
   public ResourceLocation getTextureLocation(Projectile entity) {
      return GLOW;
   }
}
