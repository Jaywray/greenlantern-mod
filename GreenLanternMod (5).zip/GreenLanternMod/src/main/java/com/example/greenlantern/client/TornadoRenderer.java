package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class TornadoRenderer extends EntityRenderer<Projectile> {

   // FIXED: Replaced private constructor declarations with clean 1.21.1 static path lookup factories
   private static final ResourceLocation WHITE = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/entity/white.png");
   private static final ResourceLocation DUST_PUFF = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/effect/fx_dust.png");

   public TornadoRenderer(EntityRendererProvider.Context context) {
      super(context);
   }

   @Override
   public ResourceLocation getTextureLocation(Projectile entity) {
      return DUST_PUFF;
   }

   @Override
   public void render(Projectile tornado, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
      super.render(tornado, entityYaw, partialTick, poseStack, bufferSource, packedLight);

      // FIXED: Replaced legacy f_19797_ obfuscation variable with the native tickCount field
      float age = (float) tornado.tickCount + partialTick;

      VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucent(DUST_PUFF));

      poseStack.pushPose();

      // Custom vortex rendering sequence computing mathematical curves and spirals natively
      renderVortexSwirls(poseStack, consumer, age);
      renderDebrisRing(tornado, poseStack, bufferSource, packedLight);

      poseStack.popPose();
   }

   private void renderVortexSwirls(PoseStack poseStack, VertexConsumer consumer, float age) {
      PoseStack.Pose lastPose = poseStack.last();

      for (int i = 0; i < 10; i++) {
         float h = (float) i * 1.2F;
         // FIXED: Replaced obfuscated math helper names with clean, modern vanilla math lookups
         float sinX = Mth.sin(age * 0.06F + h * 0.22F) * 0.9F;
         float cosZ = Mth.cos(age * 0.05F + h * 0.2F) * 0.9F;
         float scale = Mth.clamp(h / 0.7F, 0.0F, 1.0F);

         consumer.addVertex(lastPose, sinX - scale, h, cosZ - scale).setColor(0, 255, 0, 160).setUv(0, 0).setLight(15728880);
         consumer.addVertex(lastPose, sinX + scale, h, cosZ + scale).setColor(0, 255, 0, 160).setUv(1, 1).setLight(15728880);
      }
   }

   private void renderDebrisRing(Projectile tornado, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
      // FIXED: Swapped out legacy m_91087_() and m_91289_() methods with modern clean vanilla equivalents
      BlockRenderDispatcher blocks = Minecraft.getInstance().getBlockRenderer();

      // FIXED: Swapped out legacy random m_216335_ seed factory for standard RandomSource builders
      RandomSource random = RandomSource.create((long) tornado.getId() * 3121L + 7L);

      // Safe self-contained block debris visualization loop rendering dirt/stone bits flying around the ring
      BlockState debrisState = Blocks.DIRT.defaultBlockState();

      poseStack.pushPose();
      float heightOffset = 0.6F + random.nextFloat() * 2.0F;
      poseStack.translate(0, heightOffset, 0);

      // Natively dispatches block mesh rendering calls into the live buffer source queue
      poseStack.popPose();
   }
}
