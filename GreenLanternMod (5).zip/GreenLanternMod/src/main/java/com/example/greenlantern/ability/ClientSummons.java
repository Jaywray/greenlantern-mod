package com.example.greenlantern.ability;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class ClientSummons {
   // A thread-safe queue holding pending construct generation visual cues
   private static final Queue<Poof> WAITING = new ConcurrentLinkedQueue<>();

   private ClientSummons() {
   }

   public static void receive(int entityId, int kind, float formed) {
      WAITING.add(new Poof(entityId, kind, formed));
   }

   // Modernized polling query removing obsolete decompiler cast wrappers
   public static Poof next() {
      return WAITING.poll();
   }

   // Clean Java Record wrapper representing the construct generation instance parameters
   public static record Poof(int entityId, int kind, float formed) {
   }
}
