package com.example.greenlantern.client;

final class FlightContrails {
   private FlightContrails() {
   }
}
