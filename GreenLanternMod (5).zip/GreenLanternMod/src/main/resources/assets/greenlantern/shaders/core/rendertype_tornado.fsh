#version 150

#moj_import <greenlantern:pulse_common.glsl>

uniform float TornadoTime;
uniform float TornadoPass;

in vec4 wallInfo;
in vec2 wallUv;
in vec3 surfaceNormal;
in vec3 viewPos;

out vec4 fragColor;

const float ROUND = 30.0;
const float ABSORB = 1.4;
const float GLOW = 0.32;
const vec3 GLASS = vec3(0.30, 0.75, 0.42);

float wrappedCellEdge(vec2 p, float period) {
    vec2 ip = floor(p);
    vec2 fp = fract(p);
    vec2 nearest = vec2(0.0);
    vec2 nearestCell = vec2(0.0);
    float best = 8.0;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2 g = vec2(float(i), float(j));
            vec2 c = ip + g;
            c.x = mod(c.x, period);
            vec2 r = g + hash2(c) - fp;
            float d = dot(r, r);
            if (d < best) {
                best = d;
                nearest = r;
                nearestCell = g;
            }
        }
    }
    float edge = 8.0;
    for (int j = -2; j <= 2; j++) {
        for (int i = -2; i <= 2; i++) {
            vec2 g = nearestCell + vec2(float(i), float(j));
            vec2 c = ip + g;
            c.x = mod(c.x, period);
            vec2 r = g + hash2(c) - fp;
            vec2 between = r - nearest;
            if (dot(between, between) > 0.00001) {
                edge = min(edge, dot(0.5 * (nearest + r), normalize(between)));
            }
        }
    }
    return edge;
}

void main() {
    float solid = wallInfo.r;
    if (solid <= 0.002) {
        discard;
    }
    float t = TornadoTime;
    float up = wallInfo.g;
    float radius = wallInfo.b * 5.0;
    float h = wallUv.y;
    vec3 V = normalize(-viewPos);
    vec3 N = normalize(surfaceNormal);
    float facing = abs(dot(N, V));
    float through = 1.0 / max(facing, 0.15);
    float fres = pow(1.0 - facing, 3.0);

    float turn = t * mix(2.4, 1.1, up);
    float a = wallUv.x * 6.2831853 - turn;
    vec3 p = vec3(cos(a) * radius, h - t * 0.9, sin(a) * radius) * 0.55;
    vec3 w = p * 0.6 + vec3(0.0, 0.0, t * 0.1);
    vec3 q = p + vec3(fbm2(w), fbm2(w + vec3(5.2, 1.3, 2.7)), fbm2(w + vec3(2.1, 7.7, 4.4))) * 0.9;

    if (TornadoPass < 0.5) {
        float trans = exp(-ABSORB * energyDensity(fbm2(q)) * through * solid);
        fragColor = vec4(trans * mix(vec3(1.0), GLASS, 1.0 - trans), 1.0);
        return;
    }

    float n = fbm3(q);
    vec3 c = energyColor(n);
    float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
    c += RIOT_STRAND * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
    vec3 emit = c * min(through, 2.0) * GLOW;
    float crackMask = smoothstep(0.25, 0.6, snoise(vec3(p.xz * 0.7, h * 0.3 + t * 0.05)));
    if (crackMask > 0.0) {
        vec2 cp = vec2(fract(wallUv.x - turn / 6.2831853) * ROUND, h * 2.4);
        emit += RIOT_CRACK * 0.5 * (1.0 - smoothstep(0.0, 0.035, wrappedCellEdge(cp, ROUND))) * crackMask;
    }
    emit += RIOT_SHEEN * fres * 0.12;
    emit *= 0.95 + 0.1 * snoise(vec3(p * 9.0));
    fragColor = vec4(emit * solid, 1.0);
}
