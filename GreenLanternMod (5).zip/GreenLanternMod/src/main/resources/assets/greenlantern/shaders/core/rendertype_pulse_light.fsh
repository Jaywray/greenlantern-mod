#version 150

#moj_import <greenlantern:pulse_common.glsl>

uniform float PulseTime;
uniform float LightPass;

in vec4 shapeInfo;
in vec2 shapeUv;
in vec3 surfaceNormal;
in vec3 viewPos;

out vec4 fragColor;

const float RING_ABSORB = RIOT_ABSORB * 1.7;

void main() {
    int shape = int(shapeInfo.r * 3.0 + 0.5);
    float brightness = shapeInfo.g * 2.0;
    float fade = clamp(brightness, 0.0, 1.0);
    float fresh = shapeInfo.b;
    float seed = shapeInfo.a * 50.0;
    float t = PulseTime;
    bool light = LightPass > 0.5;
    vec3 V = normalize(-viewPos);
    vec3 N = normalize(surfaceNormal);
    float trans = 1.0;
    vec3 emit = vec3(0.0);
    if (shape == 0) {
        float facing = dot(N, V);
        if (facing <= 0.0) {
            discard;
        }
        float a = shapeUv.x * 6.2831853;
        float b = shapeUv.y * 6.2831853;
        vec3 w = vec3(cos(a) * 0.9, sin(a) * 0.9, t * 0.05 + seed);
        vec2 warp = vec2(fbm2(w + vec3(0.0, -t * 0.06, 0.0)), fbm2(w + vec3(5.2, 1.3 - t * 0.05, 2.7))) * 0.9;
        vec3 q = vec3(cos(a) * 1.9 + warp.x, sin(a) * 1.9 + warp.y, sin(b) * 0.5 + t * 0.3 + seed);
        float n = light ? fbm3(q) : fbm2(q);
        float fres = pow(1.0 - facing, 3.0);
        trans = exp(-RING_ABSORB * energyDensity(n) * facing);
        if (!light) {
            trans = mix(trans, trans * 0.5, fres);
            fragColor = vec4(mix(vec3(1.0), RIOT_GLASS * trans, fade), 1.0);
            return;
        }
        vec3 c = energyColor(n);
        float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
        c += RIOT_STRAND * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
        emit = c * (0.7 + 0.45 * facing) * mix(1.0, 0.65, 1.0 - trans)
                + vec3(0.12, 0.22, 0.14) * fresh * facing * facing
                + RIOT_EDGE * exp(-facing / 0.08)
                + RIOT_SHEEN * fres * 0.4;
        emit *= 0.95 + 0.1 * snoise(vec3(cos(a) * 30.0, sin(a) * 30.0, b * 4.0));
        fragColor = vec4(emit * fade, 1.0);
        return;
    }
    float dens;
    float n;
    if (shape == 1) {
        float r = length(shapeUv);
        float a = atan(shapeUv.y, shapeUv.x);
        n = fbm2(vec3(cos(a) * 1.4 + r * 1.5, sin(a) * 1.4, t * 1.2 + seed));
        float band = exp(-pow((r - 1.0 - 0.12 * n) / 0.28, 2.0));
        float inner = exp(-pow(r / 0.55, 2.0)) * 0.3;
        dens = (band * (0.6 + 0.6 * n) + inner) * fade;
    } else {
        float s = clamp(shapeUv.x, 0.0, 1.0);
        float a = shapeUv.y * 6.2831853;
        float arms = 0.5 + 0.5 * sin(a * 2.0 + log(0.08 + s) * 9.0 - t * 26.0);
        n = fbm2(vec3(cos(a) * 1.8, sin(a) * 1.8, s * 3.0 - t * 4.0));
        float band = pow(arms, 4.0) * (0.55 + 0.8 * smoothstep(-0.3, 0.5, n));
        float rim = pow(1.0 - abs(dot(N, V)), 1.5);
        float heat = exp(-s * 4.0);
        dens = (band * (0.5 + 0.8 * rim) + heat * 0.6) * pow(1.0 - s, 1.1) * brightness * 0.75;
        n += heat * 0.8;
    }
    trans = exp(-1.3 * dens);
    if (!light) {
        fragColor = vec4(trans * mix(vec3(1.0), RIOT_GLASS, 1.0 - trans), 1.0);
        return;
    }
    fragColor = vec4(energyColor(n) * (1.0 - trans) * 1.15, 1.0);
}
