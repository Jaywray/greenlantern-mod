#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec3 shieldPos;
out vec3 shieldNormal;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    shieldPos = vec3(UV0, (Color.r * 2.0 - 1.0) * 0.08);
    shieldNormal = Normal;
}
