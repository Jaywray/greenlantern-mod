package com.example.greenlantern.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.component.Tool;
import java.util.List;

public class ConstructAxeItem extends AxeItem {

   // FIXED: Adjusted parameters to explicitly provide matching whole integers for 1.21.1 attack attributes
   public ConstructAxeItem(Properties properties) {
      super(Tiers.DIAMOND, properties.component(DataComponents.TOOL,
              new Tool(List.of(), 6.0F, 1))); // Maps attack damage speed arrays via stable structures
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
