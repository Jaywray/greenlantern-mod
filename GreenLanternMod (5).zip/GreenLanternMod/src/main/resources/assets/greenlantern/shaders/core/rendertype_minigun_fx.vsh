#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 fxUv;
out vec4 fxInfo;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    fxUv = UV0;
    fxInfo = Color;
}
