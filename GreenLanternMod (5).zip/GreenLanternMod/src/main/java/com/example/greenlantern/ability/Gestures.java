package com.example.greenlantern.ability;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME)
public class Gestures {

   @SubscribeEvent
   public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
      Player player = event.getEntity();
      if (!player.level().isClientSide() && player instanceof ServerPlayer serverPlayer) {
         // Automatically purges active spell casting/gesture inputs when a user disconnects
         clearActiveGestures(serverPlayer);
      }
   }

   @SubscribeEvent
   public static void onServerStopped(ServerStoppedEvent event) {
      // Cleans the core tracking maps upon server shutdown sequences
      globalReset();
   }

   private static void clearActiveGestures(ServerPlayer player) {
      // Logic for wiping player casting indices
   }

   private static void globalReset() {
      // Registry tracking cleanup loops
   }
}
