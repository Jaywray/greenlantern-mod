package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

public class RiotShieldRenderer {

   public static void renderShieldBarrier(PoseStack poseStack, MultiBufferSource bufferSource, float alpha, String customPath) {
      ResourceLocation texture = getDynamicShieldTexture(customPath);
      VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucent(texture));
      PoseStack.Pose lastPose = poseStack.last();

      poseStack.pushPose();

      // Builds a flat, high-density energy blocking surface matrix natively
      consumer.addVertex(lastPose, -1.0F, -1.0F, 0.0F).setColor(0, 255, 0, (int)(alpha * 255)).setUv(0, 0).setLight(15728880);
      consumer.addVertex(lastPose, 1.0F, 1.0F, 0.0F).setColor(0, 255, 0, (int)(alpha * 255)).setUv(1, 1).setLight(15728880);

      poseStack.popPose();
   }

   // FIXED: Modernized the path dynamic allocation method to use the 1.21.1 static factory format layout
   public static ResourceLocation getDynamicShieldTexture(String path) {
      return ResourceLocation.fromNamespaceAndPath("greenlantern", path);
   }
}
