package com.example.greenlantern.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class LanternGearScreen extends Screen {
   private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/gui/lantern_gear.png");

   public LanternGearScreen() {
      super(Component.translatable("gui.greenlantern.gear_screen"));
   }

   @Override
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      super.render(guiGraphics, mouseX, mouseY, partialTick);
      // Draw uniform inventory slots and charge stat levels cleanly
      int leftPos = (this.width - 176) / 2;
      int topPos = (this.height - 166) / 2;
      guiGraphics.blit(BACKGROUND, leftPos, topPos, 0, 0, 176, 166);
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
