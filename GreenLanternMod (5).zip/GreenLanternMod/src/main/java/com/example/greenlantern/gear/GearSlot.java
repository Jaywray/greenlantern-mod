package com.example.greenlantern.gear;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;

public enum GearSlot {
   RING(0, "ring"),
   BATTERY(1, "battery"),
   SUIT(2, "suit");

   private final int index;
   private final String key;

   GearSlot(int index, String key) {
      this.index = index;
      this.key = key;
   }

   public int getIndex() {
      return this.index;
   }

   public String getKey() {
      return this.key;
   }

   // FIXED: Replaced legacy decompiled m_237115_ method with clean 1.21.1 Component.translatable
   public Component getDisplayName() {
      return Component.translatable("gear.greenlantern.slot." + this.key);
   }

   public EquipmentSlot toVanillaSlot() {
      return this == SUIT ? EquipmentSlot.CHEST : EquipmentSlot.MAINHAND;
   }
}
