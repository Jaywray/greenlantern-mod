#version 150

uniform vec3 BubbleCamera;
uniform float BubbleTime;
uniform float BubbleFade;
uniform float BubbleHit;
uniform float BubblePass;
uniform vec3 BubbleRadius;
uniform float BubbleSweep;
uniform float BubbleSweepOut;
uniform vec3 BubbleFrom;
uniform vec3 BubbleOutFrom;
uniform float BubbleDust;
uniform float BubbleTilt;
uniform float BubbleDome;

in vec3 bubblePos;
in vec3 bubbleWarp;
in float bubbleCrack;

out vec4 fragColor;

const float SHELL = 0.075;
const float SHELL_THICK = 0.1;
const float ABSORB = 0.8;
const float ABSORB_INSIDE = 0.5;
const float GLOW = 0.62;

vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 permute(vec4 x) { return mod289(((x * 34.0) + 1.0) * x); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v) {
    const vec2 C = vec2(1.0 / 6.0, 1.0 / 3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i);
    vec4 p = permute(permute(permute(
            i.z + vec4(0.0, i1.z, i2.z, 1.0))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0))
            + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ * ns.x + ns.yyyy;
    vec4 y = y_ * ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0) * 2.0 + 1.0;
    vec4 s1 = floor(b1) * 2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}

float fbm2(vec3 p) {
    return 0.6 * snoise(p) + 0.3 * snoise(p * 2.03 + vec3(1.7, 9.2, 3.1));
}

float fbm3(vec3 p) {
    float s = 0.5 * snoise(p);
    p = p * 2.03 + vec3(1.7, 9.2, 3.1);
    s += 0.25 * snoise(p);
    p = p * 2.01 + vec3(4.1, 2.3, 7.7);
    s += 0.125 * snoise(p);
    return s * 1.6;
}

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec2 hash2(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453);
}

float cellEdge(vec2 p, float period) {
    vec2 ip = floor(p);
    vec2 fp = fract(p);
    vec2 nearest = vec2(0.0);
    vec2 nearestCell = vec2(0.0);
    float best = 8.0;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2 g = vec2(float(i), float(j));
            vec2 c = ip + g;
            c.x = mod(c.x, period);
            vec2 r = g + hash2(c) - fp;
            float d = dot(r, r);
            if (d < best) {
                best = d;
                nearest = r;
                nearestCell = g;
            }
        }
    }
    float edge = 8.0;
    for (int j = -2; j <= 2; j++) {
        for (int i = -2; i <= 2; i++) {
            vec2 g = nearestCell + vec2(float(i), float(j));
            vec2 c = ip + g;
            c.x = mod(c.x, period);
            vec2 r = g + hash2(c) - fp;
            vec2 between = r - nearest;
            if (dot(between, between) > 0.00001) {
                edge = min(edge, dot(0.5 * (nearest + r), normalize(between)));
            }
        }
    }
    return edge;
}

bool lightPass;
int shellSteps;
float thin;
float sweepFar;

void shellLight(vec3 start, vec3 dir, float len, vec3 warp, float t, float absorb, inout vec3 emit, inout float trans) {
    float dt = len / float(shellSteps);
    float glowShare = min(1.0, SHELL_THICK / max(len, 1.0e-4));
    for (int i = 0; i < 4; i++) {
        if (i >= shellSteps) {
            break;
        }
        vec3 p = start + dir * (dt * (float(i) + 0.5));
        float into = (1.0 - length(p / BubbleRadius)) * BubbleRadius.x;
        vec3 q = vec3(p.x * 1.7, (p.y - t * 0.16) * 1.5, p.z * 1.7 + into * 5.0) + warp;
        float n;
        if (lightPass) {
            n = fbm3(q);
            float glow = smoothstep(-0.05, 0.5, n);
            vec3 c = mix(vec3(0.06, 0.33, 0.18), vec3(0.27, 0.72, 0.42), glow) + vec3(0.18, 0.15, 0.12) * glow * glow * glow;
            float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
            c += vec3(0.15, 0.40, 0.26) * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
            emit += c * (dt / SHELL_THICK) * glowShare * mix(1.0, trans, 0.35);
        } else {
            n = fbm2(q);
        }
        float dens = clamp(0.6 + 0.8 * n, 0.15, 1.4) * (1.0 - 0.6 * thin);
        trans *= exp(-absorb * dens * dt / SHELL_THICK);
    }
}

void mist(vec3 start, vec3 dir, float len, float t, float amount, inout vec3 emit, inout float trans) {
    float dt = len * 0.5;
    for (int i = 0; i < 2; i++) {
        vec3 p = start + dir * (dt * (float(i) + 0.5));
        float n = snoise(vec3(p.x * 0.9, p.y * 0.9 - t * 0.12, p.z * 0.9 + t * 0.03));
        float low = smoothstep(0.4, -1.2, p.y - BubbleDome * 0.5 * BubbleRadius.y);
        float dens = (0.04 + 0.22 * low) * (0.6 + 0.6 * n) * amount;
        if (lightPass) {
            emit += vec3(0.06, 0.33, 0.18) * 0.75 * dens * dt * trans;
        }
        trans *= exp(-0.7 * dens * dt);
    }
}

float sweepPast(vec3 p, float t) {
    float r = BubbleRadius.x;
    vec3 up = vec3(0.0, 1.0, 0.0) - BubbleFrom * BubbleFrom.y;
    up = dot(up, up) < 1.0e-6 ? vec3(1.0, 0.0, 0.0) : normalize(up);
    float past = BubbleSweep - (r - dot(p, BubbleFrom) - BubbleTilt * abs(dot(p, up)));
    if (BubbleSweepOut > -5.0) {
        past = min(past, r - dot(p, BubbleOutFrom) - BubbleSweepOut);
    }
    if (past > sweepFar) {
        return past;
    }
    vec3 across = normalize(cross(up, BubbleFrom));
    float lat = dot(p, across);
    float waver = 0.08 * sin(lat * 3.1 + t * 3.1) + 0.05 * sin(lat * 5.3 - t * 4.3)
            + 0.05 * snoise(p * 1.3 + vec3(0.0, t * 0.6, 0.0));
    return past + waver;
}

float grainShown(vec3 p, float past, float t) {
    if (BubbleDust <= 0.001) {
        return 1.0;
    }
    float grain = 0.5 + 0.5 * snoise(p * 24.0 + vec3(t * 0.7, -t * 0.4, t * 0.5));
    float cond = mix(1.0, smoothstep(0.03, 0.9, past), BubbleDust);
    return smoothstep(grain - 0.07, grain + 0.07, cond);
}

void main() {
    float t = BubbleTime;
    lightPass = BubblePass > 0.5;
    sweepFar = BubbleDust > 0.001 ? 2.0 : 0.8;

    vec3 p = normalize(bubblePos / BubbleRadius) * BubbleRadius;
    if (BubbleDome > 0.5 && p.y < 0.0) {
        discard;
    }
    float past = sweepPast(p, t);
    if (past < 0.0) {
        discard;
    }
    float shown = grainShown(p, past, t);
    if (shown < 0.01) {
        discard;
    }
    thin = BubbleDust * (1.0 - smoothstep(0.0, 1.2, past));
    float fade = BubbleFade * shown;
    float rim = 1.0 - smoothstep(0.0, 0.4, past);
    float whole = smoothstep(1.5 * BubbleRadius.x, 2.0 * BubbleRadius.x, BubbleSweep)
            * (1.0 - smoothstep(0.0, 0.6 * BubbleRadius.x, BubbleSweepOut));
    vec3 V = normalize(p - BubbleCamera);
    vec3 N = normalize(p / (BubbleRadius * BubbleRadius));
    bool near = dot(N, V) < 0.0;
    float fres = near ? pow(1.0 - abs(dot(N, V)), 3.0) : 0.0;

    vec3 P = p / BubbleRadius;
    vec3 D = V / BubbleRadius;
    float a = dot(D, D);
    float b = 2.0 * dot(P, D);
    float ri = 1.0 - SHELL;
    float discIn = b * b - 4.0 * a * (dot(P, P) - ri * ri);
    float discOut = b * b - 4.0 * a * (dot(P, P) - 1.0);
    float tCam = -distance(p, BubbleCamera);

    float inside = 1.0 - smoothstep(ri - 0.03, ri, length(BubbleCamera / BubbleRadius));
    float absorb = mix(ABSORB, ABSORB_INSIDE, inside) * (1.0 + 2.0 * rim);
    shellSteps = lightPass ? (inside > 0.5 ? 2 : 4) : 2;

    vec3 warp = bubbleWarp;
    float groundAt = (BubbleDome > 0.5 && V.y < -1.0e-4) ? -p.y / V.y : 1.0e9;

    vec3 emit = vec3(0.0);
    float trans = 1.0;
    float before = 1.0;
    if (near) {
        if (discIn > 0.0) {
            float s = sqrt(discIn);
            float t1 = (-b - s) / (2.0 * a);
            float t2 = (-b + s) / (2.0 * a);
            shellLight(p, V, t1, warp, t, absorb, emit, trans);
            mist(p + V * t1, V, clamp(min(0.5 * (t2 - t1), groundAt - t1), 0.0, 1.0e3), t, whole, emit, trans);
        } else {
            float tOut = (-b + sqrt(max(discOut, 0.0))) / (2.0 * a);
            shellLight(p, V, min(tOut, 0.25), warp, t, absorb, emit, trans);
        }
    } else if (discIn > 0.0) {
        float s = sqrt(discIn);
        float t1 = (-b - s) / (2.0 * a);
        float t2 = (-b + s) / (2.0 * a);
        float mistStart = max(0.5 * (t1 + t2), tCam);
        if (t2 > mistStart) {
            mist(p + V * mistStart, V, t2 - mistStart, t, (1.0 - 0.75 * inside) * whole, emit, trans);
        }
        float shellStart = max(t2, tCam);
        shellLight(p + V * shellStart, V, -shellStart, warp, t, absorb, emit, trans);
        float tOut1 = (-b - sqrt(max(discOut, 0.0))) / (2.0 * a);
        vec3 front = p + V * tOut1;
        if (tCam < tOut1 && (BubbleDome < 0.5 || front.y >= 0.0)) {
            float frontPast = sweepPast(front, t);
            if (frontPast >= 0.0) {
                float frontShown = grainShown(front, frontPast, t);
                before = mix(1.0, exp(-absorb * 0.6 * (t1 - tOut1) / SHELL_THICK), frontShown < 0.01 ? 0.0 : frontShown);
            }
        }
    }

    if (!lightPass) {
        trans = mix(trans, trans * 0.5, fres);
        vec3 glass = mix(vec3(0.46, 0.86, 0.62), vec3(0.70, 0.93, 0.80), inside) * trans;
        fragColor = vec4(mix(vec3(1.0), glass, fade * (1.0 - 0.8 * thin)), 1.0);
        return;
    }

    emit *= before;
    emit *= (0.8 + 0.35 * max(dot(N, normalize(vec3(0.0, 0.65, 0.0) - 0.7 * V)), 0.0)) * GLOW * (1.0 + 0.6 * rim);
    emit += vec3(0.45, 0.87, 0.54) * 0.18 * exp(-past / 0.12);
    emit += vec3(0.30, 0.78, 0.50) * 0.22 * BubbleDust * exp(-past / 0.35);
    emit += vec3(0.27, 0.72, 0.42) * 0.55 * thin;
    float crackMask = smoothstep(0.2, 0.55, bubbleCrack) * smoothstep(0.92, 0.6, abs(N.y));
    if (crackMask > 0.001) {
        float around = atan(p.x, p.z) / 6.2831853 * 26.0;
        float e = cellEdge(vec2(around, p.y * 3.2) + warp.xy * 0.25, 26.0);
        float cracks = (1.0 - smoothstep(0.0, 0.03, e)) * crackMask;
        emit += vec3(0.20, 0.62, 0.38) * cracks * (near ? 1.0 : 0.45) * before * (1.0 - thin);
    }
    if (near) {
        emit += vec3(0.40, 0.62, 0.58) * fres * 0.4 * (1.0 + 1.5 * BubbleHit);
        vec3 sun = normalize(vec3(-0.4, 0.8, 0.45));
        emit += vec3(0.45, 0.66, 0.56) * pow(max(dot(reflect(V, N), sun), 0.0), 30.0) * 0.12;
    }
    emit *= 0.95 + 0.1 * snoise(p * 60.0);
    float glint = step(0.9988, hash(floor(p.xy * 90.0 + p.z * 37.0) + floor(t * 5.0) * 17.0));
    emit += vec3(0.30, 0.70, 0.45) * glint * 0.3;
    emit *= (1.0 + 0.05 * sin(t * 1.7)) * mix(1.0, 0.35, inside) * (1.0 + 0.6 * BubbleHit);
    fragColor = vec4(emit * fade, 1.0);
}
