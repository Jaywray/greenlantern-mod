package com.example.greenlantern.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class ConstructWheelScreen extends Screen {

   private static final ResourceLocation SHEET = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/gui/wheel.png");

   public ConstructWheelScreen() {
      super(Component.translatable("gui.greenlantern.wheel"));
   }

   // FIXED: Modernized the screen drawing sequence to accept the 1.21.1 GuiGraphics pipeline object
   @Override
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      super.render(guiGraphics, mouseX, mouseY, partialTick);
      // Custom graphic wheel blit matrices are safely processed using guiGraphics down here
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
