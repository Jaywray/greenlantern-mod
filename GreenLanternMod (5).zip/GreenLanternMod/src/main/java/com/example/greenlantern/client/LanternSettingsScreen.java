package com.example.greenlantern.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class LanternSettingsScreen extends Screen {

   private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/gui/settings.png");
   private final Screen lastScreen;
   private int imageWidth = 176;
   private int imageHeight = 166;
   private int leftPos;
   private int topPos;

   public LanternSettingsScreen(Screen lastScreen) {
      super(Component.translatable("gui.greenlantern.settings_title"));
      this.lastScreen = lastScreen;
   }

   @Override
   protected void init() {
      super.init();
      this.leftPos = (this.width - this.imageWidth) / 2;
      this.topPos = (this.height - this.imageHeight) / 2;

      // Adds a modern 1.21.1 functional back button to return to previous menus cleanly
      this.addRenderableWidget(Button.builder(Component.translatable("gui.back"), button -> this.minecraft.setScreen(this.lastScreen))
              .bounds(this.leftPos + 40, this.topPos + 130, 96, 20)
              .build());
   }

   @Override
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      super.render(guiGraphics, mouseX, mouseY, partialTick);

      // Renders the background options panel using the unified 1.21.1 graphics interface
      guiGraphics.blit(TEXTURE, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight);

      // Draws customized configuration headers over the active configuration page layout
      guiGraphics.drawString(this.font, this.title, this.leftPos + 10, this.topPos + 10, 0x404040, false);
   }

   @Override
   public void onClose() {
      this.minecraft.setScreen(this.lastScreen);
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
