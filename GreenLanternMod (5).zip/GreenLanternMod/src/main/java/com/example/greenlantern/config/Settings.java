package com.example.greenlantern.config;

public class Settings {

   public static final CooldownBridge BUBBLE_COOLDOWN = new CooldownBridge(200);
   public static final CooldownBridge LASER_COOLDOWN = new CooldownBridge(100);
   public static final CooldownBridge MINIGUN_COOLDOWN = new CooldownBridge(300);
   public static final CooldownBridge BUBBLE_DURATION = new CooldownBridge(400);

   // FIXED: Added the missing configuration text string bridge required by the speech processing microphone logic
   public static final TextConfigBridge MIC_LANGUAGE = new TextConfigBridge("en-US");

   public static class CooldownBridge {
      private final int defaultTicks;

      public CooldownBridge(int defaultTicks) {
         this.defaultTicks = defaultTicks;
      }

      public int ticks() {
         return this.defaultTicks;
      }
   }

   public static class TextConfigBridge {
      private final String defaultValue;

      public TextConfigBridge(String defaultValue) {
         this.defaultValue = defaultValue;
      }

      public String text() {
         // Allows microphone tracking hooks to query speech locales seamlessly
         return this.defaultValue;
      }
   }
}
