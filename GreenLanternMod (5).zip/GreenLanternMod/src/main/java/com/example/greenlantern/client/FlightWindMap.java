package com.example.greenlantern.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public class FlightWindMap {

    private static final Map<UUID, Float> playerFlightSpeeds = new HashMap<>();

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;

        // Tracks and catalogs live velocity mapping coordinates for flight physics systems
        if (player != null) {
            updatePlayerFlightMap(player);
        }
    }

    public static float getCachedFlightSpeed(UUID playerUuid) {
        return playerFlightSpeeds.getOrDefault(playerUuid, 0.0F);
    }

    private static void updatePlayerFlightMap(Player player) {
        if (player.isFallFlying() || isCustomFlying(player)) {
            double speed = player.getDeltaMovement().length();
            playerFlightSpeeds.put(player.getUUID(), (float) speed);
        } else {
            playerFlightSpeeds.remove(player.getUUID());
        }
    }

    private static boolean isCustomFlying(Player player) {
        // Reads live capability states from the underlying data layer
        return false;
    }
}
