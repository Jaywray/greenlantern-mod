package com.example.greenlantern.item;

import net.minecraft.world.entity.player.Player;

public class MinigunHold {
   // FIXED: Modern self-contained action verifier completely free of legacy 1.20.1 packet code
   public static boolean isHoldingWeapon(Player player) {
      return player != null && player.isUsingItem() && player.getUseItem().getDescriptionId().contains("minigun");
   }
}
