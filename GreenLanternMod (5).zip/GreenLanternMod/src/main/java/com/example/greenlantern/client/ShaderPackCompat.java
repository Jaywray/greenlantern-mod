package com.example.greenlantern.client;

import com.mojang.logging.LogUtils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.slf4j.Logger;

public final class ShaderPackCompat {
   private static final Logger LOGGER = LogUtils.getLogger();
   private static boolean looked = false;
   private static boolean warned = false;
   private static Object api;
   private static Method packInUse;
   private static Method shadowPass;

   private ShaderPackCompat() {
   }

   public static boolean shaderPackInUse() {
      return found() && ask(packInUse);
   }

   public static boolean inShadowPass() {
      return found() && ask(shadowPass);
   }

   private static boolean found() {
      if (!looked) {
         look();
      }

      return api != null;
   }

   private static boolean ask(Method question) {
      try {
         return (Boolean)question.invoke(api);
      } catch (InvocationTargetException e) {
         warn(e.getCause());
         return false;
      } catch (RuntimeException | ReflectiveOperationException e) {
         warn(e);
         api = null;
         return false;
      }
   }

   private static void look() {
      looked = true;

      try {
         Class<?> irisApi = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
         packInUse = irisApi.getMethod("isShaderPackInUse");
         shadowPass = irisApi.getMethod("isRenderingShadowPass");
         api = irisApi.getMethod("getInstance").invoke((Object)null);
         LOGGER.info("Found Oculus/Iris: with a shader pack on, constructs are drawn after the pack finishes each frame");
      } catch (ClassNotFoundException var1) {
         api = null;
      } catch (LinkageError | RuntimeException | ReflectiveOperationException e) {
         warn(e);
         api = null;
      }

   }

   private static void warn(Throwable problem) {
      if (!warned) {
         warned = true;
         LOGGER.warn("Couldn't ask Oculus/Iris whether a shader pack is on, so constructs may not show with one", problem);
      }

   }
}
