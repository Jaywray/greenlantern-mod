package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import java.io.IOException;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class LaserShaders {

   private static ShaderInstance laserShader;

   @SubscribeEvent
   public static void onRegisterShaders(RegisterShadersEvent event) {
      try {
         event.registerShader(new ShaderInstance(event.getResourceProvider(),
                         net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("greenlantern", "laser"),
                         DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP),
                 shader -> laserShader = shader
         );
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public static ShaderInstance getLaserShader() {
      return laserShader;
   }
}
