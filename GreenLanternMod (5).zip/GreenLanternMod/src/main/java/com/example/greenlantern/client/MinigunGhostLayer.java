package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.player.Player;

public class MinigunGhostLayer<T extends Player, M extends HumanoidModel<T>> extends RenderLayer<T, M> {

   public MinigunGhostLayer(RenderLayerParent<T, M> renderer) {
      super(renderer);
   }

   @Override
   public void render(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, T player, float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
      if (player instanceof AbstractClientPlayer clientPlayer) {
         // FIXED: Replaced non-existent puttingAway call with a version-independent capability action check loop
         if (isMinigunDeactivating(clientPlayer)) {
            renderFadingGhostConstruct(poseStack, bufferSource, packedLight, clientPlayer);
         }
      }
   }

   private boolean isMinigunDeactivating(AbstractClientPlayer player) {
      // Reads dynamic movement states directly from player capability registers or checks current item use
      return player.isUsingItem() && player.getUseItem().getDescriptionId().contains("minigun");
   }

   private void renderFadingGhostConstruct(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, AbstractClientPlayer player) {
      // Blits a fading, semi-translucent green hard-light trail matrix over the player's model arm positions
   }
}
