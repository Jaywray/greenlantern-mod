package com.example.greenlantern.client;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.Projectile;

public class ShieldConstructRenderer extends EntityRenderer<Projectile> {

   // FIXED: Replaced legacy constructor allocation with the modern 1.21.1 static factory instantiation
   private static final ResourceLocation SKIN = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/entity/bubble.png");

   public ShieldConstructRenderer(EntityRendererProvider.Context context) {
      super(context);
   }

   @Override
   public ResourceLocation getTextureLocation(Projectile entity) {
      return SKIN;
   }
}
