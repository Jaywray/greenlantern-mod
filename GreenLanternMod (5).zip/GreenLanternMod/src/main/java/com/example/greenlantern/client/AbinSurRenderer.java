package com.example.greenlantern.client;

import com.example.greenlantern.entity.AbinSurEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class AbinSurRenderer extends HumanoidMobRenderer<AbinSurEntity, HumanoidModel<AbinSurEntity>> {

   // FIXED: Replaced legacy constructor invocation with the modern 1.21.1 static factory method
   private static final ResourceLocation SKIN = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/entity/abin_sur.png");

   public AbinSurRenderer(EntityRendererProvider.Context context) {
      super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
   }

   @Override
   public ResourceLocation getTextureLocation(AbinSurEntity entity) {
      return SKIN;
   }
}
