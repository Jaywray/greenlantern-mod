#version 150

#moj_import <greenlantern:pulse_common.glsl>

uniform float LaserTime;
uniform float LaserPass;

in vec4 splashInfo;
in vec2 splashUv;

out vec4 fragColor;

void main() {
    float r = length(splashUv);
    if (r >= 1.0) {
        discard;
    }
    float t = LaserTime;
    float seed = splashInfo.g * 50.0;
    float brightness = splashInfo.r;
    float body = exp(-r * r * 3.5);
    if (LaserPass < 0.5) {
        float n = fbm2(vec3(splashUv * 2.2, t * 0.8 + seed));
        float trans = exp(-2.4 * body * energyDensity(n) * brightness);
        fragColor = vec4(trans * mix(vec3(1.0), RIOT_GLASS, 1.0 - trans), 1.0);
        return;
    }
    float n = fbm3(vec3(splashUv * 2.2, t * 0.8 + seed));
    float e = cellEdge(splashUv * 3.2 + vec2(seed, t * 0.35));
    float cracks = (1.0 - smoothstep(0.0, 0.05, e)) * smoothstep(1.0, 0.25, r);
    float ripple = pow(0.5 + 0.5 * sin(r * 16.0 - t * 18.0), 3.0) * smoothstep(1.0, 0.1, r);
    vec3 col = energyColor(n) * body * 0.9
            + RIOT_CRACK * cracks * (0.9 + 0.5 * snoise(vec3(splashUv * 2.5, t * 2.0))) * 1.3
            + vec3(0.27, 0.72, 0.42) * ripple * 0.25 * body
            + vec3(0.45, 0.87, 0.54) * exp(-r * r * 40.0) * 0.45;
    fragColor = vec4(col * brightness, 1.0);
}
