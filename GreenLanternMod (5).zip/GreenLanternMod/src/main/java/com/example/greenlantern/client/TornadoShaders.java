package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import java.io.IOException;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TornadoShaders {

   private static ShaderInstance tornadoShader;

   @SubscribeEvent
   public static void onRegisterShaders(RegisterShadersEvent event) {
      try {
         // FIXED: Swapped out legacy string format modes for native 1.21.1 DefaultVertexFormat object matrix configurations
         event.registerShader(new ShaderInstance(event.getResourceProvider(),
                         net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("greenlantern", "tornado"),
                         DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP),
                 shader -> tornadoShader = shader
         );
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public static ShaderInstance getTornadoShader() {
      return tornadoShader;
   }
}
