#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec3 swordPos;
out vec2 swordShape;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    swordPos = vec3(UV0, (Color.r * 2.0 - 1.0) * 0.1);
    swordShape = Color.gb;
}
