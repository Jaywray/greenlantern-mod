package com.example.greenlantern.client;

import net.minecraft.client.player.AbstractClientPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public class MinigunHands {

   @SubscribeEvent
   public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
      if (event.getEntity() instanceof AbstractClientPlayer player) {
         // Overrides both player arm model poses to grip the heavy hard-light weapon construct
         if (isWieldingMinigun(player)) {
            forceTwoHandedMinigunPose(event, player);
         }
      }
   }

   private static boolean isWieldingMinigun(AbstractClientPlayer player) {
      // Reads heavy equipment weapon tags from local data matrices
      return false;
   }

   private static void forceTwoHandedMinigunPose(RenderPlayerEvent.Pre event, AbstractClientPlayer player) {
      // Rotates and translates right and left arm joint bones smoothly into a heavy weapon holding stance
   }
}
