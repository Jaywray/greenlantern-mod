package com.example.greenlantern.client;

import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

public class PowerBatteryModel extends Model {

   public PowerBatteryModel() {
      super(RenderType::entitySolid);
   }

   @Override
   public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
      // Core 3D geometry matrix elements for drawing the lantern battery model go here
   }

   // FIXED: Modernized the asset path return statement to use the 1.21.1 static factory method layout
   public static ResourceLocation getBatteryTextureLocation(String name) {
      return ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/" + name + ".png");
   }
}
