package com.example.greenlantern.ability;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.neoforged.neoforge.registries.DeferredHolder;

public class FollowSounds {

   // Automatically synchronizes spatial audio tracking events cleanly using vanilla world dispatch systems
   public static void playTrackingSound(ServerPlayer serverPlayer) {
      if (serverPlayer == null || serverPlayer.level() == null) return;

      // FIXED: Replaced legacy custom packet code with clean, native server-to-client world sound triggers
      double x = serverPlayer.getX();
      double y = serverPlayer.getY();
      double z = serverPlayer.getZ();

      // Looks up a default ambient sound event registered within the vanilla pool as a safe fallback template
      SoundEvent defaultSound = net.minecraft.sounds.SoundEvents.BEACON_AMBIENT;

      serverPlayer.level().playSound(
              null,                // Passing null tells the server to broadcast this audio clip to ALL nearby tracking players
              x, y, z,
              defaultSound,
              SoundSource.PLAYERS,
              1.0F,                // Volume level intensity
              1.0F                 // Audio pitch frequency profile
      );
   }
}
