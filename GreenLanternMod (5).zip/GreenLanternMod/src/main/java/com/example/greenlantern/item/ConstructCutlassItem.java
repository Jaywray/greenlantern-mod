package com.example.greenlantern.item;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;

public class ConstructCutlassItem extends SwordItem {

   public ConstructCutlassItem(Properties properties) {
      super(Tiers.DIAMOND, properties);
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
