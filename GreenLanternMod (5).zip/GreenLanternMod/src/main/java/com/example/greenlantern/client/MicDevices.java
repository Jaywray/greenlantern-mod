package com.example.greenlantern.client;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;

public class MicDevices {
   public static final AudioFormat FORMAT = new AudioFormat(16000.0F, 16, 1, true, false);
   private static final String PRIMARY = "Primary Sound Capture Driver";
   private static final long REFRESH_MILLIS = 3000L;
   private static final AtomicBoolean LOOKING = new AtomicBoolean(false);
   private static volatile List<String> names = List.of();
   private static volatile long checkedAt = 0L;

   public static List<String> names() {
      long now = System.currentTimeMillis();
      if (now - checkedAt > 3000L && LOOKING.compareAndSet(false, true)) {
         checkedAt = now;
         Thread thread = new Thread(MicDevices::look, "Green Lantern mic list");
         thread.setDaemon(true);
         thread.start();
      }

      return names;
   }

   private static void look() {
      try {
         List<String> found = new ArrayList();

         for(Mixer.Info info : AudioSystem.getMixerInfo()) {
            if (!info.getName().equals("Primary Sound Capture Driver") && canCapture(AudioSystem.getMixer(info)) && !found.contains(info.getName())) {
               found.add(info.getName());
            }
         }

         found.sort(String.CASE_INSENSITIVE_ORDER);
         names = List.copyOf(found);
      } catch (RuntimeException var8) {
      } finally {
         checkedAt = System.currentTimeMillis();
         LOOKING.set(false);
      }

   }

   private static boolean canCapture(Mixer mixer) {
      for(Line.Info info : mixer.getTargetLineInfo()) {
         if (TargetDataLine.class.isAssignableFrom(info.getLineClass())) {
            return true;
         }
      }

      return false;
   }

   public static TargetDataLine open(String name) throws LineUnavailableException {
      DataLine.Info wanted = new DataLine.Info(TargetDataLine.class, FORMAT);
      TargetDataLine line = null;
      if (name.isEmpty()) {
         line = (TargetDataLine)AudioSystem.getLine(wanted);
      } else {
         for(Mixer.Info info : AudioSystem.getMixerInfo()) {
            Mixer mixer = AudioSystem.getMixer(info);
            if (info.getName().equals(name) && mixer.isLineSupported(wanted)) {
               line = (TargetDataLine)mixer.getLine(wanted);
               break;
            }
         }

         if (line == null) {
            throw new LineUnavailableException(name + " is not connected");
         }
      }

      line.open(FORMAT, 6400);
      line.start();
      return line;
   }

   public static final class Meter {
      private final String device;
      private volatile boolean running = true;
      private volatile boolean failed = false;
      private volatile float level = 0.0F;

      public Meter(String device) {
         this.device = device;
         Thread thread = new Thread(this::listen, "Green Lantern mic meter");
         thread.setDaemon(true);
         thread.start();
      }

      private void listen() {
         try {
            TargetDataLine line = MicDevices.open(this.device);

            int peak;
            try {
               for(byte[] buffer = new byte[1600]; this.running; this.level = (float)peak / 32768.0F) {
                  int read = line.read(buffer, 0, buffer.length);
                  peak = 0;

                  for(int i = 0; i + 1 < read; i += 2) {
                     peak = Math.max(peak, Math.abs((short)(buffer[i] & 255 | buffer[i + 1] << 8)));
                  }
               }
            } catch (Throwable var7) {
               if (line != null) {
                  try {
                     line.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (line != null) {
               line.close();
            }
         } catch (RuntimeException | LineUnavailableException var8) {
            this.failed = true;
         }

      }

      public String device() {
         return this.device;
      }

      public float level() {
         return this.level;
      }

      public boolean failed() {
         return this.failed;
      }

      public void stop() {
         this.running = false;
      }
   }
}
