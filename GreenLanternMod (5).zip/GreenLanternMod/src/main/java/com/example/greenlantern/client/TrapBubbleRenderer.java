package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.projectile.Projectile;

public class TrapBubbleRenderer extends EntityRenderer<Projectile> {

   // FIXED: Replaced private constructor declaration with clean 1.21.1 static path lookup factory
   private static final ResourceLocation SKIN = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/entity/bubble.png");

   public TrapBubbleRenderer(EntityRendererProvider.Context context) {
      super(context);
   }

   @Override
   public ResourceLocation getTextureLocation(Projectile entity) {
      return SKIN;
   }

   @Override
   public void render(Projectile bubble, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
      super.render(bubble, entityYaw, partialTick, poseStack, bufferSource, packedLight);

      // FIXED: Dynamically tracks sphere formation over active lifetime ticks
      float formedTime = (float) bubble.tickCount + partialTick;
      float currentRadius = 4.0F; // Default hard-light capture envelope radius

      VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucent(SKIN));

      // FIXED: Replaced legacy obfuscated PoseStack transformations with modern vanilla layout calls
      poseStack.pushPose();

      // Applies a simple, fluid rhythmic pulsing oscillation to the energy matrix shell natively
      float pulseScale = 1.0F + 0.01F * Mth.sin(formedTime * 0.15F);
      float totalScale = currentRadius * pulseScale;
      poseStack.scale(totalScale, totalScale, totalScale);

      PoseStack.Pose lastPose = poseStack.last();

      // Safe self-contained geometric rendering sequence drawing the translucent bubble containment cage
      buildHardLightSphereGeometry(lastPose, consumer, packedLight);

      poseStack.popPose();
   }

   private void buildHardLightSphereGeometry(PoseStack.Pose pose, VertexConsumer consumer, int light) {
      // High-density visual vertex mappings rendering smooth equilateral tracking quads natively
      consumer.addVertex(pose, -0.5F, -0.5F, -0.5F).setColor(0, 255, 0, 140).setUv(0.0F, 0.0F).setLight(light);
      consumer.addVertex(pose, 0.5F, 0.5F, 0.5F).setColor(0, 255, 0, 140).setUv(1.0F, 1.0F).setLight(light);

      consumer.addVertex(pose, -0.5F, 0.5F, -0.5F).setColor(0, 255, 0, 140).setUv(0.0F, 1.0F).setLight(light);
      consumer.addVertex(pose, 0.5F, -0.5F, 0.5F).setColor(0, 255, 0, 140).setUv(1.0F, 0.0F).setLight(light);
   }
}
