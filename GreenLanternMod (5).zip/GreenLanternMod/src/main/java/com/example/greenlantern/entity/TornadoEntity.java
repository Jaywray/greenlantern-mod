package com.example.greenlantern.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import java.util.List;

public class TornadoEntity extends Projectile {

   public TornadoEntity(EntityType<? extends Projectile> type, Level level) {
      super(type, level);
   }

   @Override
   protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
      // Initializes tracking parameters for structural width and vortex height attributes
   }

   @Override
   public void tick() {
      super.tick();
      this.checkInsideBlocks();

      // Standalone vacuum mechanics: pulls nearby entities upward into the vortex spinning matrix natively
      if (!this.level().isClientSide()) {
         double radius = 6.0D;
         AABB captureZone = this.getBoundingBox().inflate(radius, 8.0D, radius);
         List<LivingEntity> targets = this.level().getEntitiesOfClass(LivingEntity.class, captureZone, entity -> entity != this.getOwner());

         for (LivingEntity target : targets) {
            // Pulls targets inward toward the central storm eye and hurls them upward
            Vec3 pullVector = new Vec3(this.getX() - target.getX(), 0.2D, this.getZ() - target.getZ()).normalize().scale(0.3D);
            target.setDeltaMovement(target.getDeltaMovement().add(pullVector.x, 0.15D, pullVector.z));
            target.hurtMarked = true;

            // Applies periodic hard-light continuous slicing damage directly inside this script loop
            if (this.tickCount % 10 == 0) {
               if (this.getOwner() instanceof LivingEntity attacker) {
                  target.hurt(this.damageSources().mobAttack(attacker), 3.0F);
               } else {
                  target.hurt(this.damageSources().magic(), 3.0F);
               }
            }
         }
      }

      // Moves the physical tornado tracking node forward through the level grid layout safely
      Vec3 movement = this.getDeltaMovement();
      this.setPos(this.getX() + movement.x, this.getY() + movement.y, this.getZ() + movement.z);

      if (this.tickCount > 200) {
         this.discard();
      }
   }
}
