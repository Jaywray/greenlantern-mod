package com.example.greenlantern.client;

import net.minecraft.client.KeyMapping;

public class ModKeybinds {
   public static final String CATEGORY = "key.categories.greenlantern";
   public static final KeyMapping[] SLOT_KEYS = new KeyMapping[]{new KeyMapping("key.greenlantern.slot_1", 86, "key.categories.greenlantern"), new KeyMapping("key.greenlantern.slot_2", 66, "key.categories.greenlantern"), new KeyMapping("key.greenlantern.slot_3", 78, "key.categories.greenlantern"), new KeyMapping("key.greenlantern.slot_4", 77, "key.categories.greenlantern"), new KeyMapping("key.greenlantern.slot_5", 44, "key.categories.greenlantern")};
   public static final KeyMapping SUIT_UP = new KeyMapping("key.greenlantern.suit_up", 90, "key.categories.greenlantern");
   public static final KeyMapping ROLL_LEFT = new KeyMapping("key.greenlantern.roll_left", 88, "key.categories.greenlantern");
   public static final KeyMapping ROLL_RIGHT = new KeyMapping("key.greenlantern.roll_right", 67, "key.categories.greenlantern");
   public static final KeyMapping SETTINGS = new KeyMapping("key.greenlantern.settings", 93, "key.categories.greenlantern");
}
