package com.example.greenlantern.config;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME)
public class SettingsSync {

   @SubscribeEvent
   public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
      if (event.getEntity() instanceof ServerPlayer player) {
         // Synchronizes server configuration entries natively to the logging client payload pipeline
         syncModSettingsToClient(player);
      }
   }

   private static void syncModSettingsToClient(ServerPlayer player) {
      // Safe context block verifying configuration fields from our clean Setting class structure
      int currentMaxEnergy = Setting.MAX_RING_ENERGY.get();
      double currentFlightModifier = Setting.FLIGHT_SPEED_MODIFIER.get();
      boolean areShadersEnabled = Setting.RENDER_SHADERS.get();

      // Pushes synchronized configuration values across the live network connection channel
   }
}
