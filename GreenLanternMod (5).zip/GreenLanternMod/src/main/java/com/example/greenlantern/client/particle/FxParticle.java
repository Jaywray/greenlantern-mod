package com.example.greenlantern.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.TextureSheetParticle;

// FIXED: Swapped Particle for TextureSheetParticle to inherit vanilla rendering math completely
public class FxParticle extends TextureSheetParticle {

   protected FxParticle(ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
      super(level, x, y, z, xSpeed, ySpeed, zSpeed);
      this.friction = 0.98F;
      this.xd = xSpeed;
      this.yd = ySpeed;
      this.zd = zSpeed;
      this.lifetime = 30;
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public void tick() {
      super.tick();
      this.alpha = 1.0F - ((float) this.age / (float) this.lifetime);
   }
}
