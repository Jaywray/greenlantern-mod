package com.example.greenlantern.client;

import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import java.util.function.Function;

public class ModRenderTypes {

   // FIXED: Replaced the massive chain of legacy obfuscated m_ methods with clean 1.21.1 standard vanilla render types
   public static final Function<ResourceLocation, RenderType> GLOW = (texture) ->
           RenderType.entityTranslucentCull(texture);

   public static final Function<ResourceLocation, RenderType> SHIELD_BARRIER = (texture) ->
           RenderType.entityTranslucent(texture);

   public static RenderType getGlowLayer(ResourceLocation texture) {
      return GLOW.apply(texture);
   }
}
