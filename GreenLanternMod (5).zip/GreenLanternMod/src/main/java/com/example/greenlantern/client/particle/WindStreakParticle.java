package com.example.greenlantern.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.TextureSheetParticle;

// FIXED: Swapped Particle for TextureSheetParticle to inherit vanilla rendering math completely
public class WindStreakParticle extends TextureSheetParticle {

   protected WindStreakParticle(ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
      super(level, x, y, z, xSpeed, ySpeed, zSpeed);
      this.friction = 0.95F; // Custom friction adjustment for high-speed wind streaks
      this.xd = xSpeed;
      this.yd = ySpeed;
      this.zd = zSpeed;
      this.lifetime = 20 + this.random.nextInt(10);
   }

   // FIXED: Overrides the mandatory abstract method required by Particle in 1.21.1
   @Override
   public ParticleRenderType getRenderType() {
      // Tells the engine to render the vortex streaks using the standard translucent sprite sheets
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public void tick() {
      super.tick();
      // Applies a simple fade-out alpha scale profile over its lifetime ticks
      this.alpha = 1.0F - ((float) this.age / (float) this.lifetime);
   }
}
