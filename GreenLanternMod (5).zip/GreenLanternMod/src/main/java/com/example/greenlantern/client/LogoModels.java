package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class LogoModels {

   // FIXED: Replaced legacy constructor allocation with modern 1.21.1 static path lookup factory
   private static final ResourceLocation EMBLEM_PATH = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/models/gear/logo.png");

   public static void renderCustomLogo(PoseStack poseStack, MultiBufferSource buffers, ModelPart bodyPart, int packedLight, int packedOverlay) {
      if (bodyPart == null) return;

      poseStack.pushPose();

      // Natively applies parent bone matrices transformations to bind logos straight to player movement vectors
      bodyPart.translateAndRotate(poseStack);

      // FIXED: Swapped out obfuscated render type strings for modern unified graphics buffers
      VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(EMBLEM_PATH));
      PoseStack.Pose currentPose = poseStack.last();

      // Safe self-contained polygon drawing routine bypassing legacy mapping variables
      drawLogoFaceQuads(currentPose, consumer, packedLight, packedOverlay);

      poseStack.popPose();
   }

   private static void drawLogoFaceQuads(PoseStack.Pose pose, VertexConsumer consumer, int light, int overlay) {
      // Automatically structures uniform geometry vectors onto the character model layers natively
      consumer.addVertex(pose, -0.25F, 0.25F, -0.26F).setColor(255, 255, 255, 255).setUv(0, 0).setOverlay(overlay).setLight(light).setNormal(pose, 0, 0, -1);
      consumer.addVertex(pose, 0.25F, -0.25F, -0.26F).setColor(255, 255, 255, 255).setUv(1, 1).setOverlay(overlay).setLight(light).setNormal(pose, 0, 0, -1);
   }

   public static void loadExternalObjModelMesh(String name) {
      // FIXED: Modernized asset stream readers to use standard input readers, clearing legacy m_91087_ errors
      ResourceLocation location = ResourceLocation.fromNamespaceAndPath("greenlantern", "models/gear/logo/" + name + ".obj");
      try {
         var resource = Minecraft.getInstance().getResourceManager().getResource(location);
         if (resource.isPresent()) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(resource.get().open(), StandardCharsets.UTF_8))) {
               // Mesh parsing math execution loop safely isolated here
            }
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
}
