package com.example.greenlantern.registry;

import com.example.greenlantern.item.ConstructAxeItem;
import com.example.greenlantern.item.ConstructCutlassItem;
import com.example.greenlantern.item.ConstructHoeItem;
import com.example.greenlantern.item.ConstructMinigunItem;
import com.example.greenlantern.item.ConstructPickaxeItem;
import com.example.greenlantern.item.ConstructShovelItem;
import com.example.greenlantern.item.PowerBatteryItem;
import com.example.greenlantern.item.PowerRingItem;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
   // The standard NeoForge 1.21.1 way of building an Item registry
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("greenlantern");

   // RegistryObjects are converted over to modern DeferredItems
   public static final DeferredItem<Item> POWER_RING = ITEMS.register("power_ring", 
       () -> new PowerRingItem(new Item.Properties().stacksTo(1))
   );
   
   public static final DeferredItem<Item> CONSTRUCT_CUTLASS = ITEMS.register("construct_cutlass", 
       () -> new ConstructCutlassItem(new Item.Properties())
   );
   
   public static final DeferredItem<Item> CONSTRUCT_MINIGUN = ITEMS.register("construct_minigun", 
       () -> new ConstructMinigunItem(new Item.Properties().stacksTo(1))
   );
   
   public static final DeferredItem<Item> CONSTRUCT_PICKAXE = ITEMS.register("construct_pickaxe", 
       () -> new ConstructPickaxeItem(new Item.Properties())
   );
   
   public static final DeferredItem<Item> CONSTRUCT_AXE = ITEMS.register("construct_axe", 
       () -> new ConstructAxeItem(new Item.Properties())
   );
   
   public static final DeferredItem<Item> CONSTRUCT_SHOVEL = ITEMS.register("construct_shovel", 
       () -> new ConstructShovelItem(new Item.Properties())
   );
   
   public static final DeferredItem<Item> CONSTRUCT_HOE = ITEMS.register("construct_hoe", 
       () -> new ConstructHoeItem(new Item.Properties())
   );
   
   public static final DeferredItem<Item> POWER_BATTERY = ITEMS.register("power_battery", 
       () -> new PowerBatteryItem(ModBlocks.POWER_BATTERY.get(), new Item.Properties())
   );

   // Simple registration method to cleanly link directly into your main NeoForge setup class
   public static void register(IEventBus eventBus) {
       ITEMS.register(eventBus);
   }
}
