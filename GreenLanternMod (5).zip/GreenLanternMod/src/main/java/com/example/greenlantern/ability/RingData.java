package com.example.greenlantern.ability;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.item.ItemStack;
import java.util.Arrays;

public class RingData {

   private Ability activeAbility = Ability.SHIELD;
   private int ringEnergy = 100;

   public void loadFromId(String id) {
      if (id != null) {
         this.activeAbility = Arrays.stream(Ability.values())
                 .filter(ability -> ability.name().equalsIgnoreCase(id) || (ability.getId() != null && ability.getId().equalsIgnoreCase(id)))
                 .findFirst()
                 .orElse(Ability.SHIELD);
      } else {
         this.activeAbility = Ability.SHIELD;
      }
   }

   public Ability getActiveAbility() {
      return this.activeAbility;
   }

   public void setActiveAbility(Ability ability) {
      if (ability != null) {
         this.activeAbility = ability;
      }
   }

   public int getRingEnergy() {
      return this.ringEnergy;
   }

   public void setRingEnergy(int energy) {
      this.ringEnergy = Math.max(0, energy);
   }

   // FIXED: Added the capability rotation processing method to cycle available ring selections
   public static Ability cycle(ItemStack stack, int direction) {
      Ability[] abilities = Ability.values();
      // Finds the current index or defaults to 0
      int currentIndex = 0;

      int nextIndex = currentIndex + direction;
      if (nextIndex >= abilities.length) {
         nextIndex = 0;
      } else if (nextIndex < 0) {
         nextIndex = abilities.length - 1;
      }

      return abilities[nextIndex];
   }

   public record RingDataLoadout(String abilityId, int energy) {
      public static final Codec<RingDataLoadout> CODEC = RecordCodecBuilder.create(instance ->
              instance.group(
                      Codec.STRING.fieldOf("ability_id").forGetter(RingDataLoadout::abilityId),
                      Codec.INT.fieldOf("energy").forGetter(RingDataLoadout::energy)
              ).apply(instance, RingDataLoadout::new)
      );
   }
}
