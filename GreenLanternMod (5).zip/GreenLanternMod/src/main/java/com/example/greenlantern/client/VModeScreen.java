package com.example.greenlantern.client;

import com.example.greenlantern.ability.Ability;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;

public class VModeScreen extends Screen {

   private static final ResourceLocation CARD = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/gui/vmode_card.png");
   private static final ResourceLocation CARD_PICKED = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/gui/vmode_card_picked.png");

   private final boolean isBubbleMode;
   private Ability leftAbility;
   private Ability rightAbility;
   private boolean pickedRight = false;

   public VModeScreen(boolean bubble) {
      super(Component.translatable(bubble ? "gui.greenlantern.bubblemode.title" : "gui.greenlantern.vmode.title"));
      this.isBubbleMode = bubble;
      this.leftAbility = bubble ? Ability.SHIELD : Ability.LASER;
      this.rightAbility = bubble ? Ability.CAPTURE_BUBBLE : Ability.MINIGUN;
   }

   @Override
   protected void init() {
      super.init();
      if (this.minecraft != null) {
         this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 256) {
         this.onClose();
         return true;
      }
      return super.keyPressed(keyCode, scanCode, modifiers);
   }

   @Override
   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      double centerOffset = mouseX - ((double) this.width / 2.0D);
      this.pickedRight = centerOffset > 0;

      executeServerSelectionSync();
      return true;
   }

   private void executeServerSelectionSync() {
      // FIXED: Safely bypasses external packet class dependencies via native client command string dispatches
      if (this.minecraft != null && this.minecraft.player != null) {
         String choiceName = this.pickedRight ? this.rightAbility.getId() : this.leftAbility.getId();
         this.minecraft.player.connection.sendChat("/greenlantern select " + choiceName);
         this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.ARROW_HIT_PLAYER, 1.0F));
      }
      this.onClose();
   }

   @Override
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      super.render(guiGraphics, mouseX, mouseY, partialTick);

      int midX = this.width / 2;
      int midY = this.height / 2;

      guiGraphics.blit(this.pickedRight ? CARD : CARD_PICKED, midX - 120, midY - 60, 0, 0, 100, 120);
      guiGraphics.blit(this.pickedRight ? CARD_PICKED : CARD, midX + 20, midY - 60, 0, 0, 100, 120);

      guiGraphics.drawCenteredString(this.font, this.title, midX, midY - 90, 0xFFFFFF);
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }
}
