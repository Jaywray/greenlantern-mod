#version 150

in vec2 fxUv;
in vec4 fxInfo;

out vec4 fragColor;

const vec3 HOT = vec3(0.45, 0.87, 0.54);
const vec3 DEEP = vec3(0.20, 0.62, 0.38);

void main() {
    vec3 bright = fxInfo.rgb * 2.0;
    float kind = fxInfo.a;

    if (kind < 0.25) {
        float across = abs(fxUv.y);
        float ends = smoothstep(0.0, 0.2, fxUv.x) * (1.0 - smoothstep(0.7, 1.0, fxUv.x));
        vec3 c = HOT * exp(-across * across * 30.0) * 1.25 + DEEP * exp(-across * across * 3.0) * 0.7;
        fragColor = vec4(c * ends * bright, 1.0);
        return;
    }
    float r2 = dot(fxUv, fxUv);
    if (kind < 0.75) {
        fragColor = vec4((HOT * exp(-r2 * 9.0) + DEEP * exp(-r2 * 2.5) * 0.6) * bright, 1.0);
        return;
    }
    vec2 d = fxUv;
    float star = exp(-abs(d.x) * 18.0) * exp(-abs(d.y) * 2.2) + exp(-abs(d.y) * 18.0) * exp(-abs(d.x) * 2.2);
    fragColor = vec4((HOT * (exp(-r2 * 12.0) + star * 0.8) + DEEP * exp(-r2 * 3.0) * 0.5) * bright, 1.0);
}
