#version 150

#moj_import <greenlantern:pulse_common.glsl>

uniform sampler2D DepthSampler;
uniform vec2 ScreenSize;
uniform mat4 ProjMat;
uniform vec3 VolumeCamera;
uniform float VolumeTime;
uniform float VolumePass;
uniform float CloudRadius;
uniform float CloudDensity;
uniform float CloudFlash;

in vec3 localPos;
in vec3 viewPos;

out vec4 fragColor;

void main() {
    bool lightPass = VolumePass > 0.5;
    vec3 C = VolumeCamera;
    vec3 V = normalize(localPos - C);
    float b = dot(C, V);
    float c = dot(C, C) - CloudRadius * CloudRadius;
    float disc = b * b - c;
    if (disc <= 0.0 || CloudDensity <= 0.001) {
        discard;
    }
    float s = sqrt(disc);
    float t0 = max(-b - s, 0.0);
    float t1 = min(-b + s, sceneDistance(DepthSampler, ScreenSize, ProjMat, viewPos));
    if (t1 <= t0) {
        discard;
    }
    int steps = lightPass ? 8 : 4;
    float dt = (t1 - t0) / float(steps);
    float t = VolumeTime;
    vec3 entry = C + V * t0;
    vec3 swirl = vec3(snoise(entry * 0.35 + vec3(t * 0.2)), snoise(entry * 0.35 + vec3(7.1, t * 0.2, 3.3)), 0.0) * 0.9;
    float trans = 1.0;
    vec3 emit = vec3(0.0);
    for (int i = 0; i < 8; i++) {
        if (i >= steps) {
            break;
        }
        vec3 p = C + V * (t0 + dt * (float(i) + 0.5));
        float r = length(p) / CloudRadius;
        vec3 q = p * (2.2 / CloudRadius) + vec3(swirl.xy, 0.0) + vec3(0.0, -t * 0.45, t * 0.12);
        float n = lightPass ? fbm3(q) : fbm2(q);
        float shape = pow(clamp(1.0 - r, 0.0, 1.0), 1.3);
        float dens = max(0.0, shape * (0.5 + 1.0 * n)) * CloudDensity * (3.2 / CloudRadius);
        if (lightPass) {
            vec3 col = energyColor(n) * 1.4;
            col += vec3(0.45, 0.87, 0.54) * CloudFlash * pow(max(1.0 - r * 1.5, 0.0), 2.0) * 2.5;
            emit += col * dens * dt * trans;
        }
        trans *= exp(-dens * dt * 2.0);
        if (trans < 0.002) {
            break;
        }
    }
    if (lightPass) {
        fragColor = vec4(emit, 1.0);
    } else {
        fragColor = vec4(trans * mix(vec3(1.0), RIOT_GLASS, 1.0 - trans), 1.0);
    }
}
