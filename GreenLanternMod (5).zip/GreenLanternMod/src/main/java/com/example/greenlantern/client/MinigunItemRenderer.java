package com.example.greenlantern.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class MinigunItemRenderer extends BlockEntityWithoutLevelRenderer {

   public MinigunItemRenderer() {
      // FIXED: Swapped out legacy obfuscated mapping chains for modern 1.21.1 clean vanilla rendering dispatches
      super(
              Minecraft.getInstance().getBlockEntityRenderDispatcher(),
              Minecraft.getInstance().getEntityModels()
      );
   }

   @Override
   public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, com.mojang.blaze3d.vertex.PoseStack poseStack, net.minecraft.client.renderer.MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
      // Custom 3D hard-light minigun heavy weapon rendering passes are securely processed down here
   }
}
