package com.example.greenlantern.ability;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class OwnerLookup {

   // Resolves core world time metrics and target player runtime track indices cleanly
   public static long getOwnerCurrentGameTick(Player player) {
      if (player == null) return 0L;

      // FIXED: Replaced legacy obfuscated m_9236_() call with native 1.21.1 player.level() access
      Level level = player.level();

      // FIXED: Replaced m_5776_(), m_46467_(), and m_19879_() with clean vanilla fields and methods
      if (level != null && !level.isClientSide()) {
         return level.getGameTime() + (long) player.getId();
      }

      return 0L;
   }
}
