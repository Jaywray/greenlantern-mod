uniform float FormTime;
uniform float FormStart;
uniform float FormSpan;
uniform float Dissolve;

uint formHash(uvec3 p) {
    uint h = (p.x * 1664525u) ^ (p.y * 1013904223u) ^ (p.z * 2654435769u);
    h ^= h >> 16u;
    h *= 2246822519u;
    h ^= h >> 13u;
    h *= 3266489917u;
    h ^= h >> 16u;
    return h;
}

float formRand(ivec3 c, uint salt) {
    return float(formHash(uvec3(c + 4096) + uvec3(salt))) / 4294967295.0;
}

float formOrder(ivec3 c, float along) {
    return clamp(0.62 * along + 0.24 * formRand((c + 4096) / 3 - 4096, 7u) + 0.14 * formRand(c, 13u), 0.0, 1.0);
}

float formShown(ivec3 c, float along) {
    return FormTime - (FormStart + FormSpan * formOrder(c, along));
}
