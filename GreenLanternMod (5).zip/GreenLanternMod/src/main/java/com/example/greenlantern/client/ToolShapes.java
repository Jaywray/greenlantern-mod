package com.example.greenlantern.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joml.Vector3f;

final class ToolShapes {
   private static final float HALF_THICK = 0.03125F;
   private static final float PIXEL = 0.0625F;
   private static final float GLOW_IN = 0.021875F;
   private static final float LIFT = 0.001F;
   private static final float EDGE_GLOW = 0.7F;
   private static final float ROOT_TWO = (float)Math.sqrt((double)2.0F);
   static final Vector3f GRIP = new Vector3f(0.24F, 0.24F, 0.5F);
   static final Vector3f TIP = new Vector3f(0.86F, 0.86F, 0.5F);
   private static final String[] PICKAXE = new String[]{"................", "................", "......11111.....", ".....1444441bc..", "......111144ca..", "..........b441..", ".........bca441.", "........bca.141.", ".......bca..141.", "......bca...141.", ".....bca....141.", "....bca......1..", "...bca..........", "..bca...........", "..aa............", "................"};
   private static final String[] AXE = new String[]{"................", ".........11.....", "........1441....", ".......14441....", "......14444bc...", "......144434a...", ".......11b4341..", "........bca441..", ".......bca.11...", "......bca.......", ".....bca........", "....bca.........", "...bca..........", "..bca...........", "..aa............", "................"};
   private static final String[] SHOVEL = new String[]{"................", "................", "...........111..", "..........14441.", ".........144441.", "........1444441.", ".........b4441..", "........bca41...", ".......bca.1....", "......bca.......", ".....bca........", "....bca.........", "..bbca..........", "..bca...........", "...aa...........", "................"};
   private static final String[] HOE = new String[]{"................", ".......111......", "......14441.....", ".......11441bc..", ".........144c1..", "..........b441..", ".........bc11...", "........bc1.....", ".......bc1......", "......bc1.......", ".....bc1........", "....bc1.........", "...bc1..........", "..bc1...........", "..11............", "................"};
   private static final Map<Integer, List<Quad>> BUILT = new HashMap();

   private ToolShapes() {
   }

   static List<Quad> quads(int kind) {
      return (List)BUILT.computeIfAbsent(kind, ToolShapes::build);
   }

   private static String[] mask(int kind) {
      String[] var10000;
      switch (kind) {
         case 3 -> var10000 = AXE;
         case 4 -> var10000 = SHOVEL;
         case 5 -> var10000 = HOE;
         default -> var10000 = PICKAXE;
      }

      return var10000;
   }

   private static List<Quad> build(int kind) {
      String[] mask = mask(kind);
      List<Quad> quads = new ArrayList();

      for(int py = 0; py < 16; ++py) {
         for(int px = 0; px < 16; ++px) {
            char c = mask[py].charAt(px);
            if (c != '.') {
               float amount = amount(c);
               float x0 = (float)px * 0.0625F;
               float x1 = x0 + 0.0625F;
               float y1 = 1.0F - (float)py * 0.0625F;
               float y0 = y1 - 0.0625F;
               float t = 0.03125F;
               glass(quads, amount, at(x0, y0, t), at(x1, y0, t), at(x1, y1, t), at(x0, y1, t));
               glass(quads, amount, at(x0, y0, -t), at(x0, y1, -t), at(x1, y1, -t), at(x1, y0, -t));
               if (empty(mask, px - 1, py)) {
                  glass(quads, amount, at(x0, y0, -t), at(x0, y0, t), at(x0, y1, t), at(x0, y1, -t));
                  edge(quads, x0, y0, x0, y1, 0.021875F, 0.0F);
               }

               if (empty(mask, px + 1, py)) {
                  glass(quads, amount, at(x1, y0, -t), at(x1, y1, -t), at(x1, y1, t), at(x1, y0, t));
                  edge(quads, x1, y0, x1, y1, -0.021875F, 0.0F);
               }

               if (empty(mask, px, py - 1)) {
                  glass(quads, amount, at(x0, y1, -t), at(x0, y1, t), at(x1, y1, t), at(x1, y1, -t));
                  edge(quads, x0, y1, x1, y1, 0.0F, -0.021875F);
               }

               if (empty(mask, px, py + 1)) {
                  glass(quads, amount, at(x0, y0, -t), at(x1, y0, -t), at(x1, y0, t), at(x0, y0, t));
                  edge(quads, x0, y0, x1, y0, 0.0F, 0.021875F);
               }
            }
         }
      }

      return List.copyOf(quads);
   }

   private static float amount(char c) {
      float var10000;
      switch (c) {
         case '1' -> var10000 = 1.0F;
         case '2' -> var10000 = 0.8F;
         case '3' -> var10000 = 0.85F;
         case '4' -> var10000 = 0.9F;
         case 'a' -> var10000 = 0.6F;
         case 'b' -> var10000 = 0.65F;
         case 'c' -> var10000 = 0.7F;
         default -> var10000 = 0.72F;
      }

      return var10000;
   }

   private static boolean empty(String[] mask, int px, int py) {
      return px < 0 || py < 0 || px >= 16 || py >= 16 || mask[py].charAt(px) == '.';
   }

   private static void glass(List<Quad> quads, float amount, float[] a, float[] b, float[] c, float[] d) {
      quads.add(new Quad(new float[][]{a, b, c, d}, new float[]{amount, amount, amount, amount}, false));
   }

   private static void edge(List<Quad> quads, float xa, float ya, float xb, float yb, float inX, float inY) {
      for(int side = -1; side <= 1; side += 2) {
         float z = (float)side * 0.03225F;
         quads.add(new Quad(new float[][]{at(xa, ya, z), at(xa + inX, ya + inY, z), at(xb + inX, yb + inY, z), at(xb, yb, z)}, new float[]{0.7F, 0.0F, 0.0F, 0.7F}, true));
      }

   }

   private static float[] at(float x, float y, float z) {
      return new float[]{x, y, 0.5F + z, (x + y) / ROOT_TWO, (x - y) / ROOT_TWO, z};
   }

   static record Quad(float[][] corners, float[] amounts, boolean glow) {
   }
}
