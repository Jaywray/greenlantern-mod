package com.example.greenlantern.registry;

import com.example.greenlantern.block.PowerBatteryBlock;
import com.example.greenlantern.block.RingLightBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, "greenlantern");

    public static final DeferredHolder<Block, PowerBatteryBlock> POWER_BATTERY =
            BLOCKS.register("power_battery", () -> new PowerBatteryBlock(BlockBehaviour.Properties.of().strength(5.0F).requiresCorrectToolForDrops()));

    public static final DeferredHolder<Block, RingLightBlock> RING_LIGHT =
            BLOCKS.register("ring_light", () -> new RingLightBlock(BlockBehaviour.Properties.of().strength(0.5F).lightLevel(state -> 15)));

    public static void register(IEventBus eventBus) {
        BLOCKS.register(eventBus);
    }
}
