package com.example.greenlantern.item;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.crafting.Ingredient;

public class ConstructTools {
   // Bridges your custom hard-light constructs cleanly to standard diamond tier properties
   public static final Tier CONSTRUCT = Tiers.DIAMOND;
}
