package com.example.greenlantern.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public class Setting {
   public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
   public static final ModConfigSpec SPEC;

   // Config entries for customizing ring properties
   public static final ModConfigSpec.IntValue MAX_RING_ENERGY;
   public static final ModConfigSpec.DoubleValue FLIGHT_SPEED_MODIFIER;
   public static final ModConfigSpec.BooleanValue RENDER_SHADERS;

   static {
      BUILDER.push("Green Lantern Mod Configurations");

      MAX_RING_ENERGY = BUILDER
              .comment("Defines the absolute maximum battery charge units a Power Ring can store.")
              .defineInRange("maxRingEnergy", 1000, 100, 10000);

      FLIGHT_SPEED_MODIFIER = BUILDER
              .comment("Modulates the standard movement velocity multipliers applied during active ring flight modes.")
              .defineInRange("flightSpeedModifier", 1.0D, 0.1D, 5.0D);

      RENDER_SHADERS = BUILDER
              .comment("Enables or disables custom pulsing hard-light glowing translucent vertex shader overlays.")
              .define("renderShaders", true);

      BUILDER.pop();
      SPEC = BUILDER.build();
   }
}
