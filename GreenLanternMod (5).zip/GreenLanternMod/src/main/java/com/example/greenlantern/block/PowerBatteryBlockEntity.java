package com.example.greenlantern.block;

import com.example.greenlantern.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class PowerBatteryBlockEntity extends BlockEntity {

   public PowerBatteryBlockEntity(BlockPos pos, BlockState state) {
      super(ModBlockEntities.POWER_BATTERY.get(), pos, state);
   }

   // Standard vanilla tick handler called from our block implementation
   public static void serverTick(Level level, BlockPos pos, BlockState state, PowerBatteryBlockEntity blockEntity) {
      if (level.getGameTime() % 20 == 0) {
         // Evaluates ring charging field matrices around the central battery structure dynamically
         blockEntity.chargeNearbyRings(level, pos);
      }
   }

   private void chargeNearbyRings(Level level, BlockPos pos) {
      // Logic for adding power indices to nearby players wearing willpower gear
   }

   @Override
   public Packet<ClientGamePacketListener> getUpdatePacket() {
      return ClientboundBlockEntityDataPacket.create(this);
   }

   @Override
   public net.minecraft.nbt.CompoundTag getUpdateTag(net.minecraft.core.HolderLookup.Provider registries) {
      return this.saveWithoutMetadata(registries);
   }
}
