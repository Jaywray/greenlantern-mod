package com.example.greenlantern.worldgen;

import net.minecraft.nbt.CompoundTag;

public class CrashSiteData {
   // Caches raw coordinate placement grids for generating Abin Sur's starship crash structure seamlessly
   public static void saveStructureData(CompoundTag tag, int x, int z) {
      if (tag != null) {
         tag.putInt("CrashSiteX", x);
         tag.putInt("CrashSiteZ", z);
      }
   }
}
