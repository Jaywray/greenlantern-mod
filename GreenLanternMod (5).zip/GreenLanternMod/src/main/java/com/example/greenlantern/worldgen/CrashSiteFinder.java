package com.example.greenlantern.worldgen;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class CrashSiteFinder {

   // Version-independent tracking maps replacing the missing inner class layout with integer path identifiers
   private static final Map<ResourceKey<Level>, Long2ObjectMap<Optional<Integer>>> FOUND = new HashMap<>();

   public static void clearCache() {
      FOUND.clear();
   }

   public static Optional<Integer> getFoundRoute(Level level, long chunkPosLong) {
      ResourceKey<Level> dimension = level.dimension();
      Long2ObjectMap<Optional<Integer>> dimensionMap = FOUND.get(dimension);
      if (dimensionMap != null) {
         return dimensionMap.get(chunkPosLong);
      }
      return Optional.empty();
   }

   public static void cacheFoundRoute(Level level, long chunkPosLong, int routeId) {
      ResourceKey<Level> dimension = level.dimension();
      FOUND.computeIfAbsent(dimension, k -> new Long2ObjectOpenHashMap<>())
              .put(chunkPosLong, Optional.of(routeId));
   }
}
