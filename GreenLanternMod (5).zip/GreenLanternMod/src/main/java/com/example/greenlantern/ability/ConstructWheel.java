package com.example.greenlantern.ability;

import net.minecraft.world.entity.player.Player;

public class ConstructWheel {

   public static void processWheelToggle(Player player, Ability ability) {
      if (player == null || ability == null) return;

      if ("construct_wheel".equals(ability.getId())) {
         displayClientSelectionWheel(player);
      }
   }

   private static void displayClientSelectionWheel(Player player) {
      // Core client-side radial rendering calls displaying green lantern weapon options
   }
}
