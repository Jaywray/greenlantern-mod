package com.example.greenlantern.client;

import net.minecraft.resources.ResourceLocation;

public class GearTextures {
   public static final ResourceLocation GREEN_LANTERN_SUIT = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/models/armor/green_lantern_suit.png");
   public static final ResourceLocation SINESTRO_SUIT = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/models/armor/sinestro_suit.png");

   public static ResourceLocation getSuitTexture(String factionId) {
      if ("sinestro".equalsIgnoreCase(factionId)) {
         return SINESTRO_SUIT;
      }
      return GREEN_LANTERN_SUIT;
   }
}
