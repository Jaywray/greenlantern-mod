#version 150

#moj_import <greenlantern:pulse_common.glsl>
#moj_import <greenlantern:construct_form.glsl>

uniform float CutlassTime;
uniform float CutlassPass;

in vec3 swordPos;
in vec2 swordShape;

out vec4 fragColor;

const vec3 EDGE_GLOW = vec3(0.30, 0.78, 0.50);

void main() {
    float t = CutlassTime;
    bool light = CutlassPass > 0.5;
    float amount = swordShape.x;

    ivec3 cell = ivec3(int(floor(swordPos.x / 0.05 + 0.137)), int(floor(swordPos.y / 0.05 + 0.291)), 0);
    float centerAlong = (float(cell.x) + 0.5 - 0.137) * 0.05;
    float shown = formShown(cell, clamp((1.32 - centerAlong) / 1.245, 0.0, 1.0));
    if (shown < 0.0) {
        discard;
    }
    float band = exp(-shown / 0.08);
    if (formRand(cell, 29u) < Dissolve) {
        discard;
    }

    if (swordShape.y > 0.5) {
        float shimmer = 0.85 + 0.15 * snoise(vec3(swordPos.x * 18.0 - t * 2.0, swordPos.y * 18.0, t * 0.6));
        fragColor = light ? vec4(EDGE_GLOW * (amount * shimmer + 0.45 * band + 0.6 * Dissolve), 1.0) : vec4(1.0);
        return;
    }

    vec3 p = vec3(swordPos.x * 8.0 - t * 1.2, swordPos.y * 8.0, swordPos.z * 30.0 + t * 0.1);
    vec3 w = p * 0.5 + vec3(0.0, 0.0, t * 0.08);
    vec2 warp = vec2(fbm2(w), fbm2(w + vec3(5.2, 1.3, 2.7))) * 0.9;
    vec3 q = p + vec3(warp, 0.0);

    if (!light) {
        float trans = exp(-mix(0.4, 2.2, amount) * energyDensity(fbm2(q)));
        fragColor = vec4(mix(RIOT_GLASS * trans, vec3(1.0), clamp(0.3 * band + Dissolve, 0.0, 1.0)), 1.0);
        return;
    }

    float n = fbm3(q);
    vec3 c = energyColor(n);
    float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
    c += RIOT_STRAND * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
    c *= 0.5 * (0.6 + 0.4 * amount);
    float crackMask = smoothstep(0.2, 0.55, snoise(vec3(swordPos.xy * 5.0, 3.0 + t * 0.03)));
    if (crackMask > 0.0) {
        float e = cellEdge(swordPos.xy * 24.0 + warp * 0.25);
        c += RIOT_CRACK * 0.6 * (1.0 - smoothstep(0.0, 0.05, e)) * crackMask;
    }
    c *= (0.95 + 0.1 * snoise(vec3(swordPos.xy * 140.0, swordPos.z * 140.0))) * (1.0 + 0.05 * sin(t * 1.7));
    c += EDGE_GLOW * (0.45 * band + 0.6 * Dissolve);
    fragColor = vec4(c, 1.0);
}
