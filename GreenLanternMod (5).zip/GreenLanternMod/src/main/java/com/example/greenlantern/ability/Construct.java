package com.example.greenlantern.ability;

import net.minecraft.world.entity.Entity;

public class Construct {

    // Validates targeting mechanics to ensure hard-light constructs don't hit their owner or passengers
    public static boolean isValidTarget(Entity target, Entity owner) {
        // FIXED: Replaced non-existent isPassengerOf method with modern getVehicle validation check
        if (target == null || target == owner || target.getVehicle() == owner) {
            return false;
        }
        return true;
    }
}
