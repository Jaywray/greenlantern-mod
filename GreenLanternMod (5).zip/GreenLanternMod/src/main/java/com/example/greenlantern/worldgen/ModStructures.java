package com.example.greenlantern.worldgen;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModStructures {

   public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES =
           DeferredRegister.create(Registries.STRUCTURE_TYPE, "greenlantern");

   public static void register(IEventBus eventBus) {
      STRUCTURE_TYPES.register(eventBus);
   }

   public static <S extends Structure> StructureType<S> registerType(String id, MapCodec<S> codec) {
      return () -> codec;
   }
}
