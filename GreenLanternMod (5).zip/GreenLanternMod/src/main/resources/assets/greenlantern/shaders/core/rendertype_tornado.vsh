#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 wallInfo;
out vec2 wallUv;
out vec3 surfaceNormal;
out vec3 viewPos;

void main() {
    vec4 view = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * view;
    viewPos = view.xyz;
    surfaceNormal = mat3(ModelViewMat) * Normal;
    wallInfo = Color;
    wallUv = UV0;
}
