package com.example.greenlantern.entity;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public class ShieldConstructEntity extends Entity {

   // Modern 1.21.1 synchronized entity data registration parameter wrappers
   private static final EntityDataAccessor<Integer> OWNER_ID = SynchedEntityData.defineId(ShieldConstructEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Float> FACING = SynchedEntityData.defineId(ShieldConstructEntity.class, EntityDataSerializers.FLOAT);
   private static final EntityDataAccessor<Boolean> CLOSING = SynchedEntityData.defineId(ShieldConstructEntity.class, EntityDataSerializers.BOOLEAN);

   private final int maxAge = 300; // 15 seconds lifetime limit profile

   public ShieldConstructEntity(EntityType<?> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public void setupShieldOwner(Player owner) {
      if (owner != null) {
         // FIXED: Swapped obfuscated data watcher calls for modern entityData.set mechanics
         this.entityData.set(OWNER_ID, owner.getId());
         this.entityData.set(FACING, owner.getYRot());
      }
   }

   public Vector3f getShieldFacingVector() {
      float yaw = this.entityData.get(FACING) * ((float) Math.PI / 180F);
      return new Vector3f(-Mth.sin(yaw), 0.0F, Mth.cos(yaw));
   }

   @Override
   public void tick() {
      super.tick();

      if (!this.level().isClientSide()) {
         // FIXED: Replaced legacy tracking variables with native tickCount and positioning fields
         if (this.tickCount > this.maxAge) {
            this.discard();
            return;
         }

         if (this.tickCount % 40 == 10) {
            this.level().playSound(null, this.getX(), this.getY() + 1.3D, this.getZ(),
                    SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 0.3F, 1.7F);
         }

         // Scans local dimensions for hostile projectile constructs to reflect them safely
         Vec3 center = this.position().add(0.0D, 1.3D, 0.0D);
         AABB boundingBox = new AABB(center, center).inflate(2.3D);
         int ownerId = this.entityData.get(OWNER_ID);

         for (Projectile projectile : this.level().getEntitiesOfClass(Projectile.class, boundingBox)) {
            if (projectile.getOwner() == null || projectile.getOwner().getId() != ownerId) {
               // Reverse projectile movement vector to bounce back hard-light threat elements
               projectile.setDeltaMovement(projectile.getDeltaMovement().scale(-1.2D));
            }
         }
      }
   }

   // FIXED: Implemented mandatory structural data serialization routines for 1.21.1 entities
   @Override
   protected void defineSynchedData(SynchedEntityData.Builder builder) {
      builder.define(OWNER_ID, 0);
      builder.define(FACING, 0.0F);
      builder.define(CLOSING, false);
   }

   @Override
   protected void readAdditionalSaveData(CompoundTag tag) {
      if (tag.contains("OwnerId")) this.entityData.set(OWNER_ID, tag.getInt("OwnerId"));
      if (tag.contains("Facing")) this.entityData.set(FACING, tag.getFloat("Facing"));
      if (tag.contains("Closing")) this.entityData.set(CLOSING, tag.getBoolean("Closing"));
   }

   @Override
   protected void addAdditionalSaveData(CompoundTag tag) {
      tag.putInt("OwnerId", this.entityData.get(OWNER_ID));
      tag.putFloat("Facing", this.entityData.get(FACING));
      tag.putBoolean("Closing", this.entityData.get(CLOSING));
   }
}
