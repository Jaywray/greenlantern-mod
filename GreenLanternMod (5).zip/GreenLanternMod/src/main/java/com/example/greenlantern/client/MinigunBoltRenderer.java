package com.example.greenlantern.client;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.Projectile;

public class MinigunBoltRenderer extends EntityRenderer<Projectile> {

   // FIXED: Replaced private constructor call with the modern static factory method
   private static final ResourceLocation GLOW = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/effect/pulse_glow.png");

   public MinigunBoltRenderer(EntityRendererProvider.Context context) {
      super(context);
   }

   @Override
   public ResourceLocation getTextureLocation(Projectile entity) {
      return GLOW;
   }
}
