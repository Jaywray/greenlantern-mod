#version 150

#moj_import <greenlantern:pulse_common.glsl>

uniform float LaserTime;
uniform float LaserPass;

in vec4 beamInfo;
in vec2 beamUv;

out vec4 fragColor;

const float GLOW = 0.45;
const float BODY = 0.16;
const float CORE = 0.05;
const float FLOW = 6.0;
const float BRIGHT = 1.35;

void main() {
    float strength = beamInfo.r;
    float halfWidth = beamInfo.g * 0.5;
    float near = beamInfo.b * smoothstep(0.0, 0.6, strength);
    float along = beamUv.x;
    float across = beamUv.y * halfWidth;
    float d = abs(across);
    float t = LaserTime;
    bool light = LaserPass > 0.5;
    float grow = strength * (0.35 + 0.65 * smoothstep(0.0, 1.2, along)) * (1.0 + 0.06 * sin(t * 46.0 - along * 1.5));
    float radius = BODY * grow;
    float hazeWidth = GLOW * grow;

    float x = d / max(radius, 1.0e-4);
    float depth = sqrt(max(1.0 - x * x, 0.0));
    float fres = pow(1.0 - depth, 3.0);
    float trans = 1.0;
    vec3 emit = vec3(0.0);
    if (x < 1.0) {
        vec3 w = vec3(along * 0.85 - t * 2.4, across * 2.0, t * 0.3);
        vec2 warp = vec2(fbm2(w), fbm2(w + vec3(5.2, 1.3, 2.7))) * 0.9;
        int steps = light ? 4 : 2;
        float dt = 2.0 * radius * depth / float(steps);
        for (int i = 0; i < 4; i++) {
            if (i >= steps) {
                break;
            }
            float z = ((float(i) + 0.5) / float(steps) * 2.0 - 1.0) * depth * radius;
            vec3 q = vec3(along * 1.7 - t * FLOW + warp.x, across * 5.0 + warp.y, z * 5.0 + t * 0.2);
            float n;
            if (light) {
                n = fbm3(q);
                vec3 c = energyColor(n);
                float strand = 1.0 - abs(snoise(q * 2.6 + vec3(3.1, 0.0, 1.7)));
                c += RIOT_STRAND * pow(strand, 12.0) * smoothstep(-0.2, 0.3, n);
                emit += c / float(steps) * mix(1.0, trans, 0.35);
            } else {
                n = fbm2(q);
            }
            trans *= exp(-RIOT_ABSORB * energyDensity(n) * dt / RIOT_THICK);
        }
        emit *= 0.55 + 0.6 * depth;
    }

    float haze = 0.0;
    if (x >= 1.0) {
        float outside = max(d - radius, 0.0) / max(hazeWidth - radius, 1.0e-4);
        float wisp = 0.6 + 0.5 * fbm2(vec3(along * 0.6 - t * 3.0, across * 3.0, t * 0.5 + 7.0));
        haze = exp(-pow(outside * 2.6, 2.0)) * wisp;
    }
    float hazeTrans = exp(-0.8 * haze);

    if (!light) {
        trans = mix(trans, trans * 0.5, fres);
        vec3 rod = mix(vec3(1.0), RIOT_GLASS * trans, step(x, 1.0));
        vec3 glass = rod * hazeTrans * mix(vec3(1.0), RIOT_GLASS, 1.0 - hazeTrans);
        fragColor = vec4(mix(vec3(1.0), glass, near), 1.0);
        return;
    }

    if (x < 1.0) {
        float core = exp(-pow(d / (CORE * grow), 2.0) * 1.6);
        emit += vec3(0.20, 0.36, 0.23) * core;
        float phase = fract((along - t * 28.0) / 1.6);
        float pulse = exp(-pow((phase - 0.5) * 1.6 / 0.35, 2.0)) * smoothstep(0.6, 1.0, along);
        emit += vec3(0.27, 0.72, 0.42) * pulse * 0.35 * (0.5 + 0.5 * depth);
        emit += RIOT_EDGE * exp(-(radius - d) / 0.012);
        emit += RIOT_SHEEN * fres * 0.4;
        emit *= (0.95 + 0.1 * snoise(vec3(along * 40.0 - t * FLOW * 24.0, across * 70.0, 0.0))) * BRIGHT;
    }
    if (haze > 0.0) {
        emit += energyColor(fbm2(vec3(along * 0.9 - t * 4.0, across * 4.0, t * 0.4 + 3.0)) - 0.25) * (1.0 - hazeTrans) * 1.6;
    }
    fragColor = vec4(emit * near, 1.0);
}
