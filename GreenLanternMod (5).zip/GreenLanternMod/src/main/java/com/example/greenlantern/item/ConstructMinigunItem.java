package com.example.greenlantern.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class ConstructMinigunItem extends Item {

   public ConstructMinigunItem(Properties properties) {
      super(properties.stacksTo(1));
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
