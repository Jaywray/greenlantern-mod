package com.example.greenlantern.item;

import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;

public class ConstructPickaxeItem extends PickaxeItem {

   public ConstructPickaxeItem(Properties properties) {
      super(Tiers.DIAMOND, properties);
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
