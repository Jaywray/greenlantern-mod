package com.example.greenlantern.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class PowerRingItem extends Item {

   public PowerRingItem(Properties properties) {
      super(properties.stacksTo(1));
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
