package com.example.greenlantern.client;

import java.util.HashMap;
import java.util.Map;

public class ClientCooldowns {
   private static final Map<String, long[]> TIMERS = new HashMap();

   public static void start(String id, int ticks) {
      long length = (long)ticks * 50L;
      TIMERS.put(id, new long[]{System.currentTimeMillis() + length, length});
   }

   public static boolean isReady(String id) {
      return millisLeft(id) <= 0L;
   }

   public static long millisLeft(String id) {
      long[] timer = (long[])TIMERS.get(id);
      return timer == null ? 0L : Math.max(0L, timer[0] - System.currentTimeMillis());
   }

   public static float fractionLeft(String id) {
      long[] timer = (long[])TIMERS.get(id);
      return timer != null && timer[1] > 0L ? Math.min(1.0F, (float)millisLeft(id) / (float)timer[1]) : 0.0F;
   }

   public static void clear() {
      TIMERS.clear();
   }
}
