package com.example.greenlantern.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

final class WindowsSpeech {
   private WindowsSpeech() {
   }

   static boolean available() {
      return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).startsWith("windows");
   }

   static Script launch(String body) throws IOException {
      Path file = Files.createTempFile("greenlantern-speech", ".ps1");
      Files.writeString(file, "\ufeff" + wrap(body), StandardCharsets.UTF_8);
      ProcessBuilder builder = new ProcessBuilder(new String[]{"powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", file.toString()});
      builder.redirectErrorStream(true);

      try {
         return new Script(builder.start(), file);
      } catch (RuntimeException | IOException e) {
         Files.deleteIfExists(file);
         throw e;
      }
   }

   private static String wrap(String body) {
      return "$ErrorActionPreference = 'Stop'\ntry { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false } catch { }\ntry {\n    Add-Type -AssemblyName System.Speech\nBODY\n} catch {\n    [Console]::Out.WriteLine('ERROR|' + $_.Exception.Message)\n    [Console]::Out.Flush()\n}\n".replace("BODY", body);
   }

   static record Script(Process process, Path file) {
      void close() {
         this.process.descendants().forEach(ProcessHandle::destroyForcibly);
         this.process.destroyForcibly();

         try {
            Files.deleteIfExists(this.file);
         } catch (IOException var2) {
         }

      }
   }
}
