package com.example.greenlantern.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import org.jetbrains.annotations.Nullable;

public class GlowParticle extends TextureSheetParticle {

   protected GlowParticle(ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
      super(level, x, y, z, xSpeed, ySpeed, zSpeed);
      this.friction = 0.96F;
      this.xd = xSpeed;
      this.yd = ySpeed;
      this.zd = zSpeed;
      this.quadSize *= 1.2F;
      this.lifetime = 20 + this.random.nextInt(10);
      this.hasPhysics = false;
   }

   @Override
   public ParticleRenderType getRenderType() {
      return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
   }

   @Override
   public void tick() {
      super.tick();
      this.alpha = 1.0F - ((float) this.age / (float) this.lifetime);
   }

   public static class Provider implements ParticleProvider<SimpleParticleType> {
      private final net.minecraft.client.particle.SpriteSet sprites;

      public Provider(net.minecraft.client.particle.SpriteSet sprites) {
         this.sprites = sprites;
      }

      @Nullable
      @Override
      public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
         GlowParticle particle = new GlowParticle(level, x, y, z, xSpeed, ySpeed, zSpeed);
         particle.pickSprite(this.sprites);
         return particle;
      }
   }
}
