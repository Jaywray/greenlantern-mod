package com.example.greenlantern.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RingModel<T extends LivingEntity> extends HumanoidModel<T> {

   public RingModel(ModelPart root) {
      super(root);
   }

   @SubscribeEvent
   public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
      // Registers custom 3D model geometry for the power ring natively under NeoForge 1.21.1
      setupRingMeshLayers(event);
   }

   private static void setupRingMeshLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
      // Maps out the physical voxel vertices for rendering the ring model over player skin layers
   }
}
