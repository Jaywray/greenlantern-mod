package com.example.greenlantern.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class PowerBatteryItemRenderer extends BlockEntityWithoutLevelRenderer {

   public PowerBatteryItemRenderer() {
      // Modernized rendering dispatches for custom 3D item models
      super(
              Minecraft.getInstance().getBlockEntityRenderDispatcher(),
              Minecraft.getInstance().getEntityModels()
      );
   }

   @Override
   public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, com.mojang.blaze3d.vertex.PoseStack poseStack, net.minecraft.client.renderer.MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
      // Renders the handheld Green Lantern Power Battery 3D model asset block natively
   }
}
