package com.example.greenlantern.client;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import java.io.IOException;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class BubbleShieldShaders {

   private static ShaderInstance bubbleShieldShader;

   @SubscribeEvent
   public static void onRegisterShaders(RegisterShadersEvent event) {
      try {
         // FIXED: Swapped out the raw layout String for a native, concrete DefaultVertexFormat object matrix reference
         event.registerShader(new ShaderInstance(event.getResourceProvider(),
                         net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("greenlantern", "bubble_shield"),
                         DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP),
                 shader -> bubbleShieldShader = shader
         );
      } catch (IOException e) {
         e.printStackTrace();
      }
   }

   public static ShaderInstance getBubbleShieldShader() {
      return bubbleShieldShader;
   }
}
