package com.example.greenlantern.registry;

import com.example.greenlantern.block.PowerBatteryBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
   // The modern NeoForge 1.21.1 way of building a Block Entity Type registry
   public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = 
       DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, "greenlantern");

   // RegistryObjects are now safely converted over to modern DeferredHolders
   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PowerBatteryBlockEntity>> POWER_BATTERY = 
       BLOCK_ENTITIES.register("power_battery", 
           () -> BlockEntityType.Builder.of(PowerBatteryBlockEntity::new, ModBlocks.POWER_BATTERY.get()).build(null)
       );

   // Simple initialization method to cleanly hook straight into your main GreenLanternMod boot bus
   public static void register(IEventBus eventBus) {
       BLOCK_ENTITIES.register(eventBus);
   }
}
