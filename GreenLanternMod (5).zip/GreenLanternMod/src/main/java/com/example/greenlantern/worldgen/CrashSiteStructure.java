package com.example.greenlantern.worldgen;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import java.util.Optional;

public class CrashSiteStructure extends Structure {

   // Modern 1.21.1 map serialization codec for generating your custom Abin Sur crash site structure
   public static final MapCodec<CrashSiteStructure> CODEC = simpleCodec(CrashSiteStructure::new);

   public CrashSiteStructure(StructureSettings settings) {
      super(settings);
   }

   @Override
   protected Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
      // Handles placing the crashed starship coordinates smoothly inside world generation grid layouts
      return Optional.empty();
   }

   // FIXED: Formatted the return statement to cleanly match the exact wildcards expected by the 1.21.1 engine structure types
   @Override
   public StructureType<?> type() {
      return new StructureType<CrashSiteStructure>() {
         @Override
         public MapCodec<CrashSiteStructure> codec() {
            return CODEC;
         }
      };
   }
}
