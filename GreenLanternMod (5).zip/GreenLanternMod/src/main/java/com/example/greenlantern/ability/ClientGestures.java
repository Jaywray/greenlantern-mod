package com.example.greenlantern.ability;

import net.minecraft.util.Mth;

public class ClientGestures {

   // Tracks client timeline markers for active ring shape tracing gestures
   public static float calculatePulseScale(long now, GestureState state) {
      if (state == null) {
         return 0.0F;
      }

      float progress = (float) (now - state.pulseFrom()) / 1000.0F;

      // FIXED: Replaced obfuscated m_14036_ method with clear, modern Mth.clamp logic
      return Mth.clamp(progress, 0.15F, 1.0F);
   }

   public static class GestureState {
      private final long pulseFrom;

      public GestureState(long pulseFrom) {
         this.pulseFrom = pulseFrom;
      }

      public long pulseFrom() {
         return this.pulseFrom;
      }
   }
}
