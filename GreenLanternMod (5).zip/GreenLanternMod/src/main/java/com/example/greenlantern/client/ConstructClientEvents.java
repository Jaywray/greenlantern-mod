package com.example.greenlantern.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ConstructClientEvents {

   @SubscribeEvent
   public static void onRegisterLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
      // Registers custom 3D model layer meshes for green lantern construct geometry natively
      registerCustomConstructLayers(event);
   }

   private static void registerCustomConstructLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
      // Maps texture coordinates and custom outline definitions onto hard-light objects
   }
}
