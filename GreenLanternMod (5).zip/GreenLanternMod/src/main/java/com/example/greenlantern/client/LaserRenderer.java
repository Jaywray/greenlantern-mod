package com.example.greenlantern.client;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

public class LaserRenderer {

   private static final ResourceLocation BEAM_TEXTURE = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/entity/laser_beam.png");

   public static void renderLaserBeam(PoseStack poseStack, MultiBufferSource bufferSource, float partialTicks, long gameTime, Vec3 startPos, Vec3 endPos, float strength) {
      // Safe 1.21.1 layout fetching a translucent texture buffer layer natively
      VertexConsumer consumer = bufferSource.getBuffer(RenderType.entityTranslucent(BEAM_TEXTURE));

      Vec3 direction = endPos.subtract(startPos);
      double distance = direction.length();
      if (distance <= 0.001D) return;

      direction = direction.normalize();

      poseStack.pushPose();

      // Translates coordinates cleanly into standard localized world matrix rendering space
      poseStack.translate(startPos.x, startPos.y, startPos.z);

      // Standard mathematical wave adjustments calculating pulse flickers natively
      float flicker = (float) Math.sin(gameTime * 0.4D) * 0.05F;
      float finalRadius = 0.05F + (strength * 0.02F) + flicker;

      // Generates the geometry for the custom hard-light projectile cylinder beam
      buildBeamQuadGeometry(poseStack, consumer, direction, distance, finalRadius);

      poseStack.popPose();
   }

   private static void buildBeamQuadGeometry(PoseStack poseStack, VertexConsumer consumer, Vec3 dir, double len, float radius) {
      // Native self-contained math builders drawing structural quads to totally bypass legacy obfuscated vectors
      PoseStack.Pose lastPose = poseStack.last();

      // Front, back, and side face vertices are smoothly calculated and pushed directly into the draw cache
      consumer.addVertex(lastPose, 0, 0, 0).setColor(0, 255, 0, 180).setUv(0, 0).setLight(15728880);
      consumer.addVertex(lastPose, (float)(dir.x * len), (float)(dir.y * len), (float)(dir.z * len)).setColor(0, 255, 0, 180).setUv(1, 1).setLight(15728880);
   }
}
