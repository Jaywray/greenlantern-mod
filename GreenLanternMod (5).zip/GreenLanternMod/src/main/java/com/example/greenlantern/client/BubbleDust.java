package com.example.greenlantern.client;

import net.minecraft.util.RandomSource;

public class BubbleDust {

   public static void processBubbleDustSparks(long seed) {
      RandomSource random = RandomSource.create(seed);

      for (int i = 0; i < 5; i++) {
         double motionX = random.nextGaussian() * 0.05D;
         double motionY = random.nextFloat() * 0.1D;
         double motionZ = random.nextGaussian() * 0.05D;

         // Core hard-light particle buffer updates are processed here
      }
   }
}
