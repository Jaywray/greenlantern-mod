package com.example.greenlantern.client;

public class ShoulderSurfingPlugin {

   // Decoupled lifecycle hook bypassing direct external compile dependencies
   public static void initializePlugin() {
      if (isShoulderSurfingPresent()) {
         registerPluginHooks();
      }
   }

   private static boolean isShoulderSurfingPresent() {
      try {
         Class.forName("com.github.exopandora.shouldersurfing.api.client.IShoulderSurfing");
         return true;
      } catch (ClassNotFoundException e) {
         return false;
      }
   }

   private static void registerPluginHooks() {
      try {
         // Optional compatibility events can be loaded safely via reflection if needed at runtime
      } catch (Exception e) {
         // Suppresses optional mod linkage errors softly
      }
   }
}
