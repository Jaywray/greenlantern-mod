package com.example.greenlantern.ability;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME)
public class MinigunFire {

   @SubscribeEvent
   public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
      Player player = event.getEntity();
      if (!player.level().isClientSide() && player instanceof ServerPlayer serverPlayer) {
         // Gracefully resets minigun thermal heat tracking and weapon spin states when a player disconnects
         resetPlayerMinigun(serverPlayer);
      }
   }

   @SubscribeEvent
   public static void onServerStopping(ServerStoppingEvent event) {
      // Purges all ongoing minigun projectile queue arrays globally on shutdown
      clearGlobalFireQueues();
   }

   private static void resetPlayerMinigun(ServerPlayer player) {
      // Logic for cooling down minigun barrel tracking
   }

   private static void clearGlobalFireQueues() {
      // Registry memory clear loops
   }
}
