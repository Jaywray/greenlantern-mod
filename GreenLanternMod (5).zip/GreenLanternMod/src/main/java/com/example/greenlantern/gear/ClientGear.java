package com.example.greenlantern.gear;

import net.minecraft.world.entity.Entity;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ClientGear {

   private static final Map<Integer, UUID> TRACKED_SUITS = new HashMap<>();

   public static void synchronizeActiveGearLayer(Entity entity) {
      if (entity == null) return;

      int runtimeId = entity.getId();
      UUID uniqueUuid = entity.getUUID();

      if (!TRACKED_SUITS.containsKey(runtimeId)) {
         TRACKED_SUITS.put(runtimeId, uniqueUuid);
      }
   }
}
