package com.example.greenlantern.client;

import net.minecraft.world.entity.player.Player;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public class BubbleFreeze {

   @SubscribeEvent
   public static void onMovementInputUpdate(MovementInputUpdateEvent event) {
      Player player = event.getEntity();

      // Completely freezes player movement vectors and jumping triggers when trapped inside a capture bubble
      if (player != null && isTrappedInBubble(player)) {
         event.getInput().forwardImpulse = 0.0F;
         event.getInput().leftImpulse = 0.0F;
         event.getInput().up = false;
         event.getInput().down = false;
         event.getInput().left = false;
         event.getInput().right = false;
         event.getInput().jumping = false;
         event.getInput().shiftKeyDown = false;
      }
   }

   private static boolean isTrappedInBubble(Player player) {
      // Scans localized ring capability data fields for active bubble constraints
      return false;
   }
}
