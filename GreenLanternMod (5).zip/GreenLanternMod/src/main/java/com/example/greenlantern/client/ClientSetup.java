package com.example.greenlantern.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

   @SubscribeEvent
   public static void onClientSetup(FMLClientSetupEvent event) {
      // Runs asset registration scripts, model layer definitions, and texture maps upon client launch
      event.enqueueWork(() -> {
         initializeClientAssets();
      });
   }

   private static void initializeClientAssets() {
      // Safe thread runtime environment maps configurations for custom entity graphics structures
   }
}
