package com.example.greenlantern.item;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

public class PowerBatteryItem extends BlockItem {

   public PowerBatteryItem(Block block, Properties properties) {
      super(block, properties.stacksTo(1));
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
