package com.example.greenlantern.client;

public class ShoulderSurfingLink {

   private static boolean isModLoadedChecked = false;
   private static boolean isShoulderSurfingPresent = false;

   // Safe, version-independent evaluation method bypassing direct package compile dependencies
   public static boolean isThirdPersonCrosshairActive() {
      if (!isModLoadedChecked) {
         try {
            // Safe lookup string evaluating if the external mod API exists on the runtime layer
            Class.forName("com.github.exopandora.shouldersurfing.api.client.IShoulderSurfing");
            isShoulderSurfingPresent = true;
         } catch (ClassNotFoundException e) {
            // Mod is not loaded in this dev runtime environment; fallback safely
            isShoulderSurfingPresent = false;
         }
         isModLoadedChecked = true;
      }
      return isShoulderSurfingPresent;
   }

   public static void setCrosshairOverrideState(boolean state) {
      if (isThirdPersonCrosshairActive()) {
         try {
            // Optional hooks can be processed here safely via reflection strings if needed
         } catch (Exception e) {
            // Suppresses optional mod linkage errors softly
         }
      }
   }
}
