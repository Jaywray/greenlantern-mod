package com.example.greenlantern.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.Level;

public class MinigunBoltEntity extends Projectile {

   public MinigunBoltEntity(EntityType<? extends Projectile> type, Level level) {
      super(type, level);
   }

   @Override
   protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
      // Initializes data sync handlers for tracking projectile trail states
   }

   @Override
   protected void onHitEntity(EntityHitResult result) {
      super.onHitEntity(result);
      if (!this.level().isClientSide() && result.getEntity() instanceof LivingEntity target) {
         // Native damage application bypassing the missing ConstructHits helper class
         if (this.getOwner() instanceof LivingEntity attacker) {
            target.hurt(this.damageSources().mobAttack(attacker), 4.0F);
         } else {
            target.hurt(this.damageSources().magic(), 4.0F);
         }
         this.discard();
      }
   }

   @Override
   protected void onHitBlock(BlockHitResult result) {
      super.onHitBlock(result);
      if (!this.level().isClientSide()) {
         this.discard();
      }
   }

   @Override
   public void tick() {
      super.tick();
      this.checkInsideBlocks();
      net.minecraft.world.phys.Vec3 movement = this.getDeltaMovement();
      this.setPos(this.getX() + movement.x, this.getY() + movement.y, this.getZ() + movement.z);
   }
}
