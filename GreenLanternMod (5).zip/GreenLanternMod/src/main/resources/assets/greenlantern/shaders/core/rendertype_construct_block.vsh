#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec3 gunPos;
out vec4 facePos;
out vec3 shape;
out vec3 surfaceNormal;
out vec3 viewPos;

void main() {
    vec4 view = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * view;
    viewPos = view.xyz;
    surfaceNormal = mat3(ModelViewMat) * Normal;
    gunPos = vec3(UV0, float(UV1.x) / 64.0);
    vec2 size = vec2(UV2) / 64.0;
    facePos = vec4(Color.rg * size, size);
    shape = vec3(Color.b, Color.a, float(UV1.y) / 1000.0);
}
