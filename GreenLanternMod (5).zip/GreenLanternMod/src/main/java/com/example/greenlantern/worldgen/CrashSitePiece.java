package com.example.greenlantern.worldgen;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;

public class CrashSitePiece {
   // Spawns custom block clusters and metallic ship debris framing at your generation coordinates
   public static void generateStructurePiece(LevelAccessor level, BlockPos pos) {
      if (level != null && pos != null) {
         level.setBlock(pos, Blocks.OBSIDIAN.defaultBlockState(), 3);
         level.setBlock(pos.above(), Blocks.FIRE.defaultBlockState(), 3);
      }
   }
}
