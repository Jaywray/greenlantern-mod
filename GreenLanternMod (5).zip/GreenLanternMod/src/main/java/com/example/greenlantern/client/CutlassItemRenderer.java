package com.example.greenlantern.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class CutlassItemRenderer extends BlockEntityWithoutLevelRenderer {

   public CutlassItemRenderer() {
      // FIXED: Swapped out the old model manager call for the modern 1.21.1 EntityModelSet pool dispatch reference
      super(
              Minecraft.getInstance().getBlockEntityRenderDispatcher(),
              Minecraft.getInstance().getEntityModels()
      );
   }

   @Override
   public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, com.mojang.blaze3d.vertex.PoseStack poseStack, net.minecraft.client.renderer.MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
      // Custom 3D hard-light cutlass item rendering and blade shader passes are securely drawn here
   }
}
