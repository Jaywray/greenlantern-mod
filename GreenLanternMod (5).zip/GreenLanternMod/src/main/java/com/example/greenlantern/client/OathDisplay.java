package com.example.greenlantern.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class OathDisplay {

   // FIXED: Replaced private constructor initialization with modern 1.21.1 static path lookup factory
   private static final ResourceLocation HALO = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/effect/pulse_glow.png");

   public static void drawOathTextOverlay(GuiGraphics guiGraphics, Component oathLine, int screenWidth, int screenHeight, float transparency) {
      if (guiGraphics == null || oathLine == null) return;

      // Custom localized graphic drawing parameters for animating green lantern recitation text layers
      int xPos = (screenWidth - 200) / 2;
      int yPos = screenHeight - 60;

      // Blits the glowing visual green halo backdrop behind our active text string
      int colorAlpha = (int)(transparency * 255.0F);
      guiGraphics.blit(HALO, xPos, yPos, 0, 0, 200, 24, 200, 24);
   }
}
