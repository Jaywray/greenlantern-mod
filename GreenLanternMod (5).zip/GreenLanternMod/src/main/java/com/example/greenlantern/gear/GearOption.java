package com.example.greenlantern.gear;

import net.minecraft.network.chat.Component;

public class GearOption {

   private final String id;
   private final int selectionValue;

   public GearOption(String id, int selectionValue) {
      this.id = id;
      this.selectionValue = selectionValue;
   }

   public String getId() {
      return this.id;
   }

   public int getSelectionValue() {
      return this.selectionValue;
   }

   // FIXED: Replaced legacy decompiled m_237115_ method with clean 1.21.1 Component.translatable
   public Component getOptionLabel() {
      return Component.translatable("gear.option.greenlantern." + this.id);
   }

   public boolean isOptionEnabled() {
      return this.selectionValue > 0;
   }
}
