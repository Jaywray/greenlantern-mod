package com.example.greenlantern.ability;

public class Cooldowns {

   // Resolves ring cooldown ticks cleanly by mapping directly to our updated Ability registrations
   public static int getAbilityCooldownTicks(Ability ability) {
      if (ability == null) {
         return 0;
      }

      return switch (ability) {
         case SHIELD -> 200;       // 10 seconds
         case LASER -> 100;        // FIXED: Maps your ring pulse blasts directly to 100 ticks (5 seconds)
         case MINIGUN -> 300;      // 15 seconds
         case TORNADO -> 400;      // 20 seconds
         case CAPTURE_BUBBLE -> 240; // 12 seconds
         default -> 0;
      };
   }
}
