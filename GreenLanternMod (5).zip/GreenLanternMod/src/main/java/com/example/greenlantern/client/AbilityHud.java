package com.example.greenlantern.client;

import net.minecraft.client.gui.GuiGraphics;

public class AbilityHud {

   // Version-agnostic rendering point that can be safely called or registered anywhere in the client pipeline
   public static void renderHud(GuiGraphics guiGraphics, float partialTick) {
      int screenWidth = guiGraphics.guiWidth();
      int screenHeight = guiGraphics.guiHeight();

      if (shouldRenderHud()) {
         drawWillpowerEnergyBar(guiGraphics, screenWidth, screenHeight);
      }
   }

   private static boolean shouldRenderHud() {
      return false;
   }

   private static void drawWillpowerEnergyBar(GuiGraphics guiGraphics, int x, int y) {
      // Overlay rendering logic
   }
}
