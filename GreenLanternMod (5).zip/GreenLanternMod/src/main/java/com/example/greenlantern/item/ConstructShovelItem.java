package com.example.greenlantern.item;

import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tiers;

public class ConstructShovelItem extends ShovelItem {

   public ConstructShovelItem(Properties properties) {
      super(Tiers.DIAMOND, properties);
   }

   @Override
   public boolean isFoil(ItemStack stack) {
      return true;
   }
}
