package com.example.greenlantern.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class TrapBubbleEntity extends Entity {

   public TrapBubbleEntity(EntityType<?> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   @Override
   public void tick() {
      super.tick();
      // Native hard-light barrier tracking variables are updated cleanly here
   }

   @Override
   protected void defineSynchedData(SynchedEntityData.Builder builder) {
      // Core tracking metrics register natively into the network data maps
   }

   @Override
   protected void readAdditionalSaveData(CompoundTag tag) {}

   @Override
   protected void addAdditionalSaveData(CompoundTag tag) {}
}
