package com.example.greenlantern.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;

public class FollowSound extends AbstractTickableSoundInstance {
   private final int targetEntityId;
   private int distanceFadeTicks = 0;

   public FollowSound(SoundEvent sound, int entityId, float volume, float pitch) {
      super(sound, SoundSource.PLAYERS, SoundInstanceProvider.getRandomSource());
      this.targetEntityId = entityId;
      this.volume = volume;
      this.pitch = pitch;
      this.looping = true;
      this.delay = 0;
      this.relative = false;
   }

   @Override
   public void tick() {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null) {
         this.stop();
         return;
      }

      Entity target = mc.level.getEntity(this.targetEntityId);
      if (target == null || !target.isAlive()) {
         this.distanceFadeTicks++;
         this.volume *= 0.9F;
         if (this.distanceFadeTicks > 20 || this.volume <= 0.01F) {
            this.stop();
         }
         return;
      }

      // Lock sound matrix positions to the physical moving entity coordinates
      this.x = (float) target.getX();
      this.y = (float) target.getY();
      this.z = (float) target.getZ();
   }

   private static class SoundInstanceProvider {
      public static net.minecraft.util.RandomSource getRandomSource() {
         return net.minecraft.util.RandomSource.create();
      }
   }
}
