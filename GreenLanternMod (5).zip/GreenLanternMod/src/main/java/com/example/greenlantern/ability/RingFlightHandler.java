package com.example.greenlantern.ability;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.GAME)
public class RingFlightHandler {

   @SubscribeEvent
   public static void onPlayerTick(PlayerTickEvent.Post event) {
      Player player = event.getEntity();
      if (player != null) {
         // Dynamically manages custom flight state calculations, velocities, and energy draw per tick
         tickPlayerFlight(player);
      }
   }

   @SubscribeEvent
   public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
      Player player = event.getEntity();
      if (!player.level().isClientSide() && player instanceof ServerPlayer serverPlayer) {
         // Safely resets active tracking vectors and flight permissions when a player leaves the server
         resetFlightData(serverPlayer);
      }
   }

   private static void tickPlayerFlight(Player player) {
      // Custom flight mechanics logic loops
   }

   private static void resetFlightData(ServerPlayer player) {
      // Flight capability reset sequences
   }
}
