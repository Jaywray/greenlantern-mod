package com.example.greenlantern.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = "greenlantern", bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

   @SubscribeEvent
   public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
      // Core rendering setup hub mapping your custom constructs and entity models natively inside NeoForge
      setupCustomModRenderers(event);
   }

   private static void setupCustomModRenderers(EntityRenderersEvent.RegisterRenderers event) {
      // Binds visual renderer scripts to custom entities like Green Lantern constructs or rings
   }
}
