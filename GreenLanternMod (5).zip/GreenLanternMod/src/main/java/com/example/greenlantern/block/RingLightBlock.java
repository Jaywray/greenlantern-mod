package com.example.greenlantern.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;

public class RingLightBlock extends Block implements SimpleWaterloggedBlock {

   public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

   public RingLightBlock(Properties properties) {
      super(properties);
      // FIXED: Replaced legacy obfuscated registration line with the clean vanilla state assignment
      this.registerDefaultState(this.stateDefinition.any().setValue(WATERLOGGED, Boolean.FALSE));
   }

   @Override
   protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      // Appends the waterlogged conditional checker to the structural state map layout
      builder.add(WATERLOGGED);
   }

   @Override
   @Deprecated
   public FluidState getFluidState(BlockState state) {
      // Automatically returns water source physics indicators if block position is submerged
      return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }
}
