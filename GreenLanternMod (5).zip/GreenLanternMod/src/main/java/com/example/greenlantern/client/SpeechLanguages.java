package com.example.greenlantern.client;

import net.minecraft.client.Minecraft;
import java.util.Locale;

public class SpeechLanguages {

   public record ModLanguageProfile(String culture) {}

   // Processes standard locale tracking metrics for microphone speech recognition matching
   public static boolean validateSpeechCulture(ModLanguageProfile language, String setting) {
      if (language == null) return false;

      // FIXED: Replaced legacy RingOath.languageFor method queries with direct lowercase locale matching
      String targetLanguage = getCurrentGameLanguageLocale();
      return language.culture().equalsIgnoreCase(targetLanguage) || language.culture().equalsIgnoreCase(setting);
   }

   public static String getEffectiveSpeechLocale(ModLanguageProfile language, String setting) {
      // FIXED: Handles safe locale selection routing without obsolete method lookups
      if (language != null) {
         return language.culture();
      }
      return "auto".equals(setting) ? getCurrentGameLanguageLocale() : setting;
   }

   // FIXED: Replaced legacy obfuscated m_91087_().f_91066_ method chains with clean 1.21.1 vanilla system mappings
   public static String getCurrentGameLanguageLocale() {
      try {
         Minecraft mc = Minecraft.getInstance();
         if (mc.getLanguageManager() != null) {
            String selectedCode = mc.getLanguageManager().getSelected();
            if (selectedCode != null) {
               return selectedCode.replace('_', '-');
            }
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return Locale.getDefault().toLanguageTag(); // Safe OS system fallback profile
   }
}
