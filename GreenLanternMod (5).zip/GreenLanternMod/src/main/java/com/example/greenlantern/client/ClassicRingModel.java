package com.example.greenlantern.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

public class ClassicRingModel<T extends LivingEntity> extends HumanoidModel<T> {

   // FIXED: Replaced legacy constructor allocation with the modern 1.21.1 static factory instantiation
   private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("greenlantern", "textures/entity/classic_ring.png");

   public ClassicRingModel(ModelPart root) {
      super(root);
   }

   public ResourceLocation getTextureLocation() {
      return TEXTURE;
   }
}
