package com.example.greenlantern.gear;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LanternGear {

   private static final Map<UUID, String> ACTIVE_SUITS = new HashMap<>();

   public static void equipLanternUniform(Player player, ItemStack stack, String factionId) {
      if (player == null || stack == null || stack.isEmpty()) return;

      // Caches active uniform variants safely without requiring legacy packet validation loops
      ACTIVE_SUITS.put(player.getUUID(), factionId);
   }

   public static String getPlayerActiveFaction(Player player) {
      if (player == null) return "none";
      return ACTIVE_SUITS.getOrDefault(player.getUUID(), "none");
   }
}
