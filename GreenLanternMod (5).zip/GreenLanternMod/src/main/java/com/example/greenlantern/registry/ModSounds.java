package com.example.greenlantern.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModSounds {
   // The modern NeoForge 1.21.1 way of building a Sound Event registry
   public static final DeferredRegister<SoundEvent> SOUNDS = 
       DeferredRegister.create(Registries.SOUND_EVENT, "greenlantern");

   // RegistryObjects are now converted over to modern DeferredHolders
   public static final DeferredHolder<SoundEvent, SoundEvent> SONIC_BOOM = SOUNDS.register("sonic_boom", 
       () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("greenlantern", "sonic_boom"))
   );
   
   public static final DeferredHolder<SoundEvent, SoundEvent> LANTERN_HUM = SOUNDS.register("lantern_hum", 
       () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("greenlantern", "lantern_hum"))
   );
   
   public static final DeferredHolder<SoundEvent, SoundEvent> LANTERN_HUM_START = SOUNDS.register("lantern_hum_start", 
       () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("greenlantern", "lantern_hum_start"))
   );
   
   public static final DeferredHolder<SoundEvent, SoundEvent> RING_KNOCK = SOUNDS.register("ring_knock", 
       () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("greenlantern", "ring_knock"))
   );
   
   public static final DeferredHolder<SoundEvent, SoundEvent> CONSTRUCT_FORM = SOUNDS.register("construct_form", 
       () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("greenlantern", "construct_form"))
   );
   
   public static final DeferredHolder<SoundEvent, SoundEvent> CONSTRUCT_POOF = SOUNDS.register("construct_poof", 
       () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("greenlantern", "construct_poof"))
   );

   // Simple initialization method to cleanly hook straight into your main GreenLanternMod boot bus
   public static void register(IEventBus eventBus) {
       SOUNDS.register(eventBus);
   }
}
