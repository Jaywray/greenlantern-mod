package com.example.greenlantern.registry;

import com.example.greenlantern.ability.RingData.RingDataLoadout;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModDataComponents {

    // Modern 1.21.1 DeferredRegister architecture for storing data components natively
    public static final DeferredRegister<DataComponentType<?>> DATA_COMPONENT_TYPES =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, "greenlantern");

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<RingDataLoadout>> RING_DATA =
            DATA_COMPONENT_TYPES.register("ring_data", () -> DataComponentType.<RingDataLoadout>builder()
                    .persistent(RingDataLoadout.CODEC)
                    .cacheEncoding()
                    .build());

    public static void register(IEventBus eventBus) {
        DATA_COMPONENT_TYPES.register(eventBus);
    }
}
